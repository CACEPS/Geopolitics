"""
Core model for:
  Oil Market Crises, Macro-Fiscal Policy and Sustainable Futures:
  Distributive Conflict in Malaysia's Energy Geopolitics

Single source of truth. Everything else in this repository (figures,
verification, Monte Carlo) imports from here. The GAMS files under gams/
implement the identical model; python/verify.py checks the two agree.

Model in one line
-----------------
    Pi_net_i(s | Omega) = Pi_gross_i(s | Omega) - c_i(Omega) * 1[s_i = S]

Gross payoffs are COMPUTED from component scores (data/components.csv),
not assigned. Capture costs are DERIVED from fiscal observables
(data/fiscal_inputs.csv). The GSF is an exogenous policy instrument.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "data"

REGIMES = ["Baseline", "Crisis", "Boom", "WarShock"]
OUTCOMES = ["TT", "TS", "ST", "SS"]
STOCH_REGIMES = ["Crisis", "Boom", "WarShock"]
PLAYERS = ["M", "RoW"]

# Greek labels used in the manuscript
OMEGA = {"Baseline": "B", "Crisis": "L", "Boom": "H", "WarShock": "W"}

# Does each player play S in this outcome? (M first letter, RoW second)
PLAYS_S = {"TT": (0, 0), "TS": (0, 1), "ST": (1, 0), "SS": (1, 1)}

# Unilateral deviation maps
DEV_M = {"TT": "ST", "ST": "TT", "TS": "SS", "SS": "TS"}
DEV_ROW = {"TT": "TS", "TS": "TT", "ST": "SS", "SS": "ST"}

WEIGHTS = {"E": 0.25, "I": 0.25, "SB": 0.25, "F": 0.25}


def _read_csv(name: str) -> list[dict]:
    with open(DATA / name, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def _params() -> dict:
    out = {}
    for row in _read_csv("regime_parameters.csv"):
        out[(row["parameter"], row["regime"])] = float(row["value"])
    return out


P = _params()


def p(name: str, regime: str = "all") -> float:
    return P[(name, regime)]


# ----------------------------------------------------------------------
# Module 2 and 3: component calibration and computed gross payoffs
# ----------------------------------------------------------------------

def load_components() -> dict[tuple[str, str, str], dict[str, float]]:
    comp = {}
    for row in _read_csv("components.csv"):
        comp[(row["regime"], row["outcome"], row["player"])] = {
            d: float(row[d]) for d in ("E", "I", "SB", "F")
        }
    return comp


COMPONENTS = load_components()


def energy_security_premium(regime: str, player: str) -> float:
    """RoW energy-security premium under Omega = W.

    Kept OUTSIDE the four normalised components so that every component
    score stays inside its declared 0 to 20 bound. Enters the payoff at
    the same weight as SB.
    """
    if regime == "WarShock" and player == "RoW":
        return p("es_premium_RoW_W", "WarShock")
    return 0.0


def gross_payoff(regime: str, outcome: str, player: str) -> float:
    c = COMPONENTS[(regime, outcome, player)]
    base = (
        WEIGHTS["E"] * c["E"]
        - WEIGHTS["I"] * c["I"]
        + WEIGHTS["SB"] * c["SB"]
        + WEIGHTS["F"] * c["F"]
    )
    return base + WEIGHTS["SB"] * energy_security_premium(regime, player)


GROSS = {
    (r, o, pl): gross_payoff(r, o, pl)
    for r in REGIMES
    for o in OUTCOMES
    for pl in PLAYERS
}

# Published Table 2 values, retained as a regression target so that any
# edit to components.csv that changes a headline payoff fails loudly.
TABLE2_PUBLISHED = {
    ("Baseline", "TT"): (1.0, 1.0), ("Baseline", "TS"): (3.0, 8.5),
    ("Baseline", "ST"): (7.0, 3.5), ("Baseline", "SS"): (9.0, 11.0),
    ("Crisis", "TT"): (-0.5, 0.5), ("Crisis", "TS"): (1.5, 7.5),
    ("Crisis", "ST"): (5.5, 2.5),  ("Crisis", "SS"): (8.5, 11.5),
    ("Boom", "TT"): (2.8, 0.8),    ("Boom", "TS"): (4.5, 8.5),
    ("Boom", "ST"): (6.5, 3.0),    ("Boom", "SS"): (9.0, 11.0),
    ("WarShock", "TT"): (2.0, 0.5), ("WarShock", "TS"): (4.0, 7.5),
    ("WarShock", "ST"): (6.5, 1.5), ("WarShock", "SS"): (10.5, 12.5),
}


def calibration_error() -> float:
    """Max absolute gap between computed and published gross payoffs.

    NOTE ON INTERPRETATION. The component scores in data/components.csv
    are a DECOMPOSITION of the published matrix, not an independent
    derivation from raw indicators. This check therefore confirms that
    the decomposition is transcribed correctly and that no later edit
    silently shifts a headline payoff. It does not, by itself, validate
    the calibration against data. Its purpose is auditability: a reader
    can see which of the four dimensions drives each payoff difference.
    """
    err = 0.0
    for (r, o), (m, w) in TABLE2_PUBLISHED.items():
        err = max(err, abs(GROSS[(r, o, "M")] - m), abs(GROSS[(r, o, "RoW")] - w))
    return err


# ----------------------------------------------------------------------
# Module 5: capture costs derived from fiscal observables
# ----------------------------------------------------------------------

FISCAL = {row["regime"]: row for row in _read_csv("fiscal_inputs.csv")}


def rent_exposure_ratio(regime: str) -> float:
    """(fuel subsidy bill + discretionary petroleum revenue) / federal revenue."""
    f = FISCAL[regime]
    return (float(f["subsidy_bill_myr_bn"]) + float(f["petro_revenue_myr_bn"])) / float(
        f["fed_revenue_myr_bn"]
    )


def fiscal_stress_amplifier(regime: str) -> float:
    return 1.0 + p("lambda_d") * float(FISCAL[regime]["deficit_pct_gdp"])


def capture_cost_M(regime: str) -> float:
    return p("kappa_M") * rent_exposure_ratio(regime) * fiscal_stress_amplifier(regime)


def capture_cost_RoW(regime: str) -> float:
    return p("kappa_R") * p("fossil_sub_share") * p("es_factor", regime)


C_M = {r: capture_cost_M(r) for r in REGIMES}
C_ROW = {r: capture_cost_RoW(r) for r in REGIMES}


# ----------------------------------------------------------------------
# Module 6: GSF as an exogenous policy instrument
# ----------------------------------------------------------------------

def windfall_pool(regime: str) -> float:
    """USD bn accumulated over the 24-month window above the trigger price."""
    raw = (
        p("price_premium", regime)
        * p("vol_mboed")
        * 30.4
        * p("window_months")
        / 1000.0
        * p("fiscal_capture")
    )
    return round(raw, 1)


POOL = {r: windfall_pool(r) for r in REGIMES}

# Resources available for side payments. The trigger never fires at
# Baseline or Crisis, so the Crisis-period fund disburses the stock
# accumulated in the preceding boom (counter-cyclical drawdown).
GSF_RESOURCES = {
    "Baseline": 0.0,
    "Crisis": POOL["Boom"],
    "Boom": POOL["Boom"],
    "WarShock": POOL["WarShock"],
}

# Side-payment potency, payoff units per USD bn deployed. Anchored so
# that full deployment of the WarShock pool at the central saving rate
# exactly neutralises the war-regime capture cost.
MU_POTENCY = round(C_M["WarShock"] / (p("sigma_central") * POOL["WarShock"]), 2)


def c_M_effective(regime: str, gsf_on: bool, sigma: float | None = None) -> float:
    if not gsf_on:
        return C_M[regime]
    s = p("sigma_central") if sigma is None else sigma
    return max(0.0, C_M[regime] - MU_POTENCY * s * GSF_RESOURCES[regime])


# ----------------------------------------------------------------------
# Module 7: Nash equilibria by full enumeration on net payoffs
# ----------------------------------------------------------------------

@dataclass(frozen=True)
class Costs:
    cM: float
    cRoW: float


def net_payoffs(regime: str, costs: Costs) -> dict[str, tuple[float, float]]:
    out = {}
    for o in OUTCOMES:
        sm, sr = PLAYS_S[o]
        out[o] = (
            GROSS[(regime, o, "M")] - sm * costs.cM,
            GROSS[(regime, o, "RoW")] - sr * costs.cRoW,
        )
    return out


def is_nash(regime: str, outcome: str, costs: Costs) -> bool:
    n = net_payoffs(regime, costs)
    return (
        n[outcome][0] >= n[DEV_M[outcome]][0]
        and n[outcome][1] >= n[DEV_ROW[outcome]][1]
    )


def equilibria(regime: str, costs: Costs) -> list[str]:
    return [o for o in OUTCOMES if is_nash(regime, outcome=o, costs=costs)]


def default_costs(regime: str, gsf_on: bool, sigma: float | None = None) -> Costs:
    return Costs(c_M_effective(regime, gsf_on, sigma), C_ROW[regime])


def dominant_strategy(regime: str, costs: Costs, player: str) -> str | None:
    """Return 'S', 'T', or None if the player has no strictly dominant strategy."""
    n = net_payoffs(regime, costs)
    idx = 0 if player == "M" else 1
    if player == "M":
        s_beats_t = n["ST"][idx] > n["TT"][idx] and n["SS"][idx] > n["TS"][idx]
        t_beats_s = n["TT"][idx] > n["ST"][idx] and n["TS"][idx] > n["SS"][idx]
    else:
        s_beats_t = n["TS"][idx] > n["TT"][idx] and n["SS"][idx] > n["ST"][idx]
        t_beats_s = n["TT"][idx] > n["TS"][idx] and n["ST"][idx] > n["SS"][idx]
    return "S" if s_beats_t else ("T" if t_beats_s else None)


def is_dominance_solvable_SS(regime: str, costs: Costs) -> bool:
    """True when S is strictly dominant for BOTH players.

    This is the precise meaning of the manuscript's 'regime-dominant'
    label and the criterion for the double-star annotation in Table 2.
    """
    return (
        dominant_strategy(regime, costs, "M") == "S"
        and dominant_strategy(regime, costs, "RoW") == "S"
    )


def prob_SS_equilibrium(gsf_on: bool, sigma: float | None = None) -> float:
    return sum(
        p("regime_prob", r) * is_nash(r, "SS", default_costs(r, gsf_on, sigma))
        for r in STOCH_REGIMES
    )


# ----------------------------------------------------------------------
# Module 8: flip thresholds, required falls, lambda sweep
# ----------------------------------------------------------------------

def c_M_star(regime: str) -> float:
    """Largest c_M consistent with (S,S): Pi_M(S,S) - Pi_M(T,S)."""
    return GROSS[(regime, "SS", "M")] - GROSS[(regime, "TS", "M")]


def c_RoW_star(regime: str) -> float:
    """Largest c_RoW consistent with (S,S): Pi_RoW(S,S) - Pi_RoW(S,T)."""
    return GROSS[(regime, "SS", "RoW")] - GROSS[(regime, "ST", "RoW")]


def required_fall(regime: str, player: str) -> float:
    """Fractional reduction in the capture cost needed to reach (S,S)."""
    c = C_M[regime] if player == "M" else C_ROW[regime]
    star = c_M_star(regime) if player == "M" else c_RoW_star(regime)
    return max(0.0, (c - star) / c)


def cost_ratio(regime: str, player: str) -> float:
    """Scale-free c / c*. Independent of kappa_M and kappa_R.

    Reporting this alongside the levels makes every equilibrium claim
    invariant to the choice of the two scaling constants.
    """
    if player == "M":
        return C_M[regime] / c_M_star(regime)
    return C_ROW[regime] / c_RoW_star(regime)


def lambda_sweep(lambdas) -> dict[float, dict[str, list[str]]]:
    return {
        lam: {
            r: equilibria(r, Costs(lam * C_M[r], lam * C_ROW[r])) for r in REGIMES
        }
        for lam in lambdas
    }


# ----------------------------------------------------------------------
# Module 9: saving-rate threshold, analytic and gridded
# ----------------------------------------------------------------------

def sigma_min_analytic(regime: str) -> float | None:
    """Smallest saving rate for which (S,S) is a Nash equilibrium.

    Solved in closed form rather than read off a grid, so the reported
    figure is not an artefact of the sweep resolution. Returns None when
    no saving rate in [0, 1] suffices (RoW-side blocked, or no GSF
    resources exist in the regime).
    """
    if C_ROW[regime] > c_RoW_star(regime):
        return None  # RoW side blocks; Malaysian side payments cannot help
    gap = C_M[regime] - c_M_star(regime)
    if gap <= 0:
        return 0.0
    denom = MU_POTENCY * GSF_RESOURCES[regime]
    if denom <= 0:
        return None
    s = gap / denom
    return s if s <= 1.0 else None


def gsf_allocation(regime: str, sigma: float) -> float:
    """USD bn actually deployed. Uses GSF_RESOURCES, not the pool.

    The distinction matters for Crisis, where the pool is zero but the
    fund disburses the boom-accumulated stock.
    """
    return GSF_RESOURCES[regime] * sigma


# ----------------------------------------------------------------------
# es(L) fragility: the thinnest margin in the model
# ----------------------------------------------------------------------

def es_critical(regime: str) -> float:
    """Value of es(Omega) at which c_RoW exactly hits its flip threshold.

    Above this value the RoW side blocks (S,S) in that regime no matter
    what Malaysia does, because the GSF acts on c_M only.
    """
    return c_RoW_star(regime) / (p("kappa_R") * p("fossil_sub_share"))


def es_margin(regime: str) -> float:
    """Fractional headroom in es(Omega) before (S,S) becomes unreachable."""
    es = p("es_factor", regime)
    return (es_critical(regime) - es) / es


# ----------------------------------------------------------------------
# Module 10: welfare (NOT equilibrium selection)
# ----------------------------------------------------------------------

def combined_welfare(regime: str, outcome: str) -> float:
    return GROSS[(regime, outcome, "M")] + GROSS[(regime, outcome, "RoW")]


def efficiency_gap(regime: str) -> float:
    return combined_welfare(regime, "SS") - combined_welfare(regime, "TT")


def expected_welfare(outcome: str, player: str) -> float:
    return sum(
        p("regime_prob", r) * GROSS[(r, outcome, player)] for r in STOCH_REGIMES
    )
