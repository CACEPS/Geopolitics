"""
Figure 3. Net regime payoffs and Nash equilibria.

Four panels, one per oil-price regime. Bars show NET payoffs, that is
gross payoff minus the capture cost when a player selects S. Equilibrium
cells are outlined: gold for the no-GSF equilibrium, green for the
additional equilibrium that GSF deployment creates at sigma = 0.6.

    python python/fig3_net_payoffs.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt

sys.path.insert(0, str(Path(__file__).resolve().parent))

import model as m

OUT = Path(__file__).resolve().parent.parent / "outputs"
OUT.mkdir(exist_ok=True)

C_M_BAR = "#2b5d7d"
C_R_BAR = "#d98b3a"
C_OFF = "#c8a02c"
C_ON = "#2e8b57"

LABEL = {"TT": "(T,T)", "TS": "(T,S)", "ST": "(S,T)", "SS": "(S,S)"}
TITLE = {
    "Baseline": r"$\Omega = B$  Baseline",
    "Crisis": r"$\Omega = L$  Crisis",
    "Boom": r"$\Omega = H$  Boom",
    "WarShock": r"$\Omega = W$  Stress test$^\dagger$",
}


def main() -> None:
    fig, axes = plt.subplots(1, 4, figsize=(15.5, 4.4), sharey=True)
    order = ["Baseline", "Crisis", "Boom", "WarShock"]

    for ax, regime in zip(axes, order):
        off = m.default_costs(regime, gsf_on=False)
        on = m.default_costs(regime, gsf_on=True)
        n_off = m.net_payoffs(regime, off)
        eq_off = m.equilibria(regime, off)
        eq_on = m.equilibria(regime, on)

        x = range(len(m.OUTCOMES))
        wid = 0.38
        mvals = [n_off[o][0] for o in m.OUTCOMES]
        rvals = [n_off[o][1] for o in m.OUTCOMES]

        ax.bar([i - wid / 2 for i in x], mvals, wid, color=C_M_BAR, label="Malaysia")
        ax.bar([i + wid / 2 for i in x], rvals, wid, color=C_R_BAR, label="Rest of World")
        ax.axhline(0, color="0.35", lw=0.8)

        for i, o in enumerate(m.OUTCOMES):
            for xi, v in ((i - wid / 2, mvals[i]), (i + wid / 2, rvals[i])):
                va = "bottom" if v >= 0 else "top"
                ax.annotate(f"{v:.1f}", (xi, v), ha="center", va=va,
                            fontsize=7.5, color="0.25",
                            xytext=(0, 2 if v >= 0 else -2), textcoords="offset points")
            if o in eq_off:
                ax.add_patch(mpatches.Rectangle(
                    (i - 0.47, ax.get_ylim()[0]), 0.94, 100,
                    facecolor=C_OFF, alpha=0.16, zorder=0))
                ax.annotate("NE", (i, max(mvals[i], rvals[i])),
                            xytext=(0, 15), textcoords="offset points",
                            ha="center", fontsize=8, weight="bold", color="#8a6d10")
            elif o in eq_on:
                ax.add_patch(mpatches.Rectangle(
                    (i - 0.47, ax.get_ylim()[0]), 0.94, 100,
                    facecolor=C_ON, alpha=0.16, zorder=0))
                ax.annotate("NE with\nGSF", (i, max(mvals[i], rvals[i])),
                            xytext=(0, 11), textcoords="offset points",
                            ha="center", fontsize=7.5, weight="bold", color="#1d6b3f")

        ax.set_xticks(list(x))
        ax.set_xticklabels([LABEL[o] for o in m.OUTCOMES])
        ax.set_title(TITLE[regime], fontsize=10.5)
        ax.annotate(
            rf"$c_M$ = {m.C_M[regime]:.2f}   $c_{{RoW}}$ = {m.C_ROW[regime]:.2f}",
            (0.5, -0.20), xycoords="axes fraction", ha="center", fontsize=8.5,
            color="0.3")
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(axis="y", alpha=0.25, lw=0.6)

    axes[0].set_ylabel("Net payoff (gross less capture cost when playing S)")
    axes[0].set_ylim(-5.5, 14.5)
    axes[0].legend(frameon=False, fontsize=9, loc="upper left")

    fig.suptitle(
        "Figure 3. Net regime payoffs and Nash equilibria: Malaysia vs. Rest of World",
        fontsize=12, y=1.02)
    fig.text(0.5, -0.06,
             "Gold shading marks the equilibrium without a Green Stabilisation Fund; "
             "green marks the additional equilibrium under GSF deployment "
             r"($\sigma$ = 0.6)." "\n"
             r"$\dagger$ $\Omega = W$ is a stylised forward-looking stress test, "
             "not a forecast.   Source: authors' computation, python/fig3_net_payoffs.py",
             ha="center", fontsize=8.5, color="0.3")

    for ext in ("pdf", "png"):
        fig.savefig(OUT / f"figure3_net_payoffs.{ext}", dpi=300,
                    bbox_inches="tight", facecolor="white")
    print(f"wrote {OUT/'figure3_net_payoffs.pdf'} and .png")


if __name__ == "__main__":
    main()
