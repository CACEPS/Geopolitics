"""
Verification harness.

Asserts every quantitative claim in the manuscript against the model in
model.py. Run this after any edit to data/ or model.py. If a headline
number in the paper changes, this fails and names the claim.

    python python/verify.py

Exit code 0 means every manuscript number reproduces.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import model as m
from montecarlo import run_monte_carlo

TOL = 5e-3  # manuscript reports 2 decimal places

FAILURES: list[str] = []
CHECKS = 0


def check(label: str, got, want, tol: float = TOL) -> None:
    global CHECKS
    CHECKS += 1
    if isinstance(want, (int, float)) and isinstance(got, (int, float)):
        ok = abs(got - want) <= tol
    else:
        ok = got == want
    status = "ok  " if ok else "FAIL"
    print(f"  [{status}] {label:<62} got={got!r:<28} paper={want!r}")
    if not ok:
        FAILURES.append(label)


def section(title: str) -> None:
    print(f"\n{title}\n{'-' * len(title)}")


# ----------------------------------------------------------------------
section("Section 3.5.1 / Note S5: component calibration")
check("computed gross payoffs reproduce Table 2 (max abs error)",
      round(m.calibration_error(), 12), 0.0, tol=1e-9)
for (r, o, pl), v in sorted(m.GROSS.items()):
    lo, hi = 0.0, 20.0
    c = m.COMPONENTS[(r, o, pl)]
    for d, x in c.items():
        assert lo <= x <= hi, f"component {d} out of 0-20 bound at {r}.{o}.{pl}: {x}"
print("  [ok  ] all 128 component scores lie inside the declared 0 to 20 bound")
CHECKS += 1

# ----------------------------------------------------------------------
section("Section 3.5.3: derived capture costs")
for r, want in [("Baseline", 8.36), ("Crisis", 7.38), ("Boom", 8.38), ("WarShock", 11.05)]:
    check(f"c_M({m.OMEGA[r]})", round(m.C_M[r], 2), want)
for r, want in [("Baseline", 7.80), ("Crisis", 8.42), ("Boom", 7.25), ("WarShock", 3.51)]:
    check(f"c_RoW({m.OMEGA[r]})", round(m.C_ROW[r], 2), want)
check("RER(L) reported in Section 5.1", round(m.rent_exposure_ratio("Crisis"), 3), 0.254)
check("RER(W) reported in Section 5.1", round(m.rent_exposure_ratio("WarShock"), 3), 0.467)

# ----------------------------------------------------------------------
section("Section 3.6: GSF pool derivation")
check("windfall pool, Omega = H (USD bn)", m.POOL["Boom"], 11.0)
check("windfall pool, Omega = W (USD bn)", m.POOL["WarShock"], 22.0)
check("side-payment potency mu", m.MU_POTENCY, 0.84)

# ----------------------------------------------------------------------
section("Section 4.2 and Table 2: equilibria and offsetting logic")
check("Baseline: M gross gain 7.0 net of c_M is below 1.0",
      round(m.GROSS[("Baseline", "ST", "M")] - m.C_M["Baseline"], 2), -1.36)
check("Baseline: RoW gross 8.5 net of c_RoW is below 1.0",
      round(m.GROSS[("Baseline", "TS", "RoW")] - m.C_ROW["Baseline"], 2), 0.70)
check("Boom: RoW net payoff at (T,S)",
      round(m.GROSS[("Boom", "TS", "RoW")] - m.C_ROW["Boom"], 2), 1.25)
for r, want in [("Baseline", ["TT"]), ("Crisis", ["TT"]), ("Boom", ["TS"]), ("WarShock", ["TS"])]:
    check(f"NE, GSF off, {m.OMEGA[r]}", m.equilibria(r, m.default_costs(r, False)), want)
for r, want in [("Baseline", ["TT"]), ("Crisis", ["SS"]), ("Boom", ["SS"]), ("WarShock", ["SS"])]:
    check(f"NE, GSF on,  {m.OMEGA[r]}", m.equilibria(r, m.default_costs(r, True)), want)

# ----------------------------------------------------------------------
section("Table 2 star annotations: dominance solvability")
for r in m.REGIMES:
    ds = m.is_dominance_solvable_SS(r, m.default_costs(r, True))
    print(f"  [info] {m.OMEGA[r]:>1}: S strictly dominant for both players with GSF on = {ds}")
print("  NOTE Omega = H and Omega = W both qualify for the double-star label.")
print("       Manuscript R1 v6 Table 2 double-stars both. Resolved; see")
print("       docs/MANUSCRIPT_CORRECTIONS.md item 7.")

# ----------------------------------------------------------------------
section("Section 4.4: crisis arithmetic")
check("M net gain at (S,S) falls short of (T,S) by",
      round(m.GROSS[("Crisis", "TS", "M")]
            - (m.GROSS[("Crisis", "SS", "M")] - m.C_M["Crisis"]), 2), 0.38)
check("sigma_min, Omega = L  [PAPER SAYS 0.15 - THIS IS THE KNOWN ERROR]",
      round(m.sigma_min_analytic("Crisis"), 2), 0.04)

# ----------------------------------------------------------------------
section("Section 4.7 and Table 3: thresholds, falls, factorial")
for r, want in [("Baseline", 6.00), ("Crisis", 7.00), ("Boom", 4.50), ("WarShock", 6.50)]:
    check(f"c_M*({m.OMEGA[r]})", round(m.c_M_star(r), 2), want)
for r, want in [("Baseline", 7.50), ("Crisis", 9.00), ("Boom", 8.00), ("WarShock", 11.00)]:
    check(f"c_RoW*({m.OMEGA[r]})", round(m.c_RoW_star(r), 2), want)
for r, want in [("Baseline", 28.3), ("Crisis", 5.1), ("Boom", 46.3), ("WarShock", 41.2)]:
    check(f"required fall in c_M, {m.OMEGA[r]} (pct)",
          round(m.required_fall(r, "M") * 100, 1), want, tol=0.1)
check("required fall in c_RoW, baseline (pct)",
      round(m.required_fall("Baseline", "RoW") * 100, 1), 3.8, tol=0.1)
for r in m.STOCH_REGIMES:
    check(f"required fall in c_RoW, {m.OMEGA[r]} (pct)",
          round(m.required_fall(r, "RoW") * 100, 1), 0.0, tol=0.1)
check("P[(S,S)] regime weighted, GSF off", m.prob_SS_equilibrium(False), 0.000)
check("P[(S,S)] regime weighted, GSF on", m.prob_SS_equilibrium(True), 1.000)
check("sigma_min, Omega = H (Section 4.7 and 5.1)",
      round(m.sigma_min_analytic("Boom"), 2), 0.42)
check("allocation at sigma = 0.42 in a boom (USD bn, Section 5.1)",
      round(m.gsf_allocation("Boom", 0.42), 1), 4.6, tol=0.05)
check("sigma_min, Omega = W", round(m.sigma_min_analytic("WarShock"), 2), 0.25)

section("Section 4.7: lambda sweep")
sweep = m.lambda_sweep([0.50, 0.75, 0.90, 1.00, 1.25])
for lam in (0.50, 0.75, 0.90, 1.00, 1.25):
    print(f"  [info] lambda={lam:4.2f}  " +
          "  ".join(f"{m.OMEGA[r]}:{','.join(sweep[lam][r]) or 'none'}" for r in m.REGIMES))
check("lambda 0.50 supports (S,S) in every regime",
      all("SS" in sweep[0.50][r] for r in m.REGIMES), True)
check("lambda 1.25 hardens B, L, H into (T,T)",
      [sweep[1.25][r] for r in ("Baseline", "Crisis", "Boom")], [["TT"], ["TT"], ["TT"]])

# ----------------------------------------------------------------------
section("Section 4.7: Monte Carlo, N = 1,000, seed 42")
mc = run_monte_carlo(n=1000, seed=42)
for r, want in [("Crisis", 0.262), ("Boom", 0.000), ("WarShock", 0.000), ("Baseline", 0.000)]:
    check(f"P[(S,S) is NE], GSF off, {m.OMEGA[r]}", mc[(r, "off")]["p"], want, tol=0.02)
for r, want in [("Crisis", 0.639), ("Boom", 0.626), ("WarShock", 1.000), ("Baseline", 0.000)]:
    check(f"P[(S,S) is NE], GSF on,  {m.OMEGA[r]}", mc[(r, "on")]["p"], want, tol=0.02)
for r in m.STOCH_REGIMES:
    d = mc[(r, "on")]
    print(f"  [info] {m.OMEGA[r]}: of the failing draws, RoW side binds in "
          f"{d['share_row_binds']*100:4.1f} pct")

# ----------------------------------------------------------------------
section("Section 4.7 welfare check (not equilibrium)")
check("E[pi(S,S)] Malaysia", round(m.expected_welfare("SS", "M"), 3), 9.075)
check("E[pi(S,S)] RoW", round(m.expected_welfare("SS", "RoW"), 3), 11.525)
check("E[pi(T,T)] Malaysia", round(m.expected_welfare("TT", "M"), 3), 1.155)
check("E[pi(T,T)] RoW", round(m.expected_welfare("TT", "RoW"), 3), 0.605)

# ----------------------------------------------------------------------
section("NEW: scale-free cost ratios (recommended Table 3 column)")
print("  c / c* is invariant to kappa_M and kappa_R, so every equilibrium")
print("  claim below holds independently of the two scaling constants.")
print(f"  {'Regime':<10} {'c_M/c_M*':>10} {'c_RoW/c_RoW*':>14}  binds")
for r in m.REGIMES:
    rm, rr = m.cost_ratio(r, "M"), m.cost_ratio(r, "RoW")
    binds = ", ".join([s for s, v in (("M", rm), ("RoW", rr)) if v > 1] or ["neither"])
    print(f"  {m.OMEGA[r]:<10} {rm:10.3f} {rr:14.3f}  {binds}")

section("NEW: es(Omega) fragility, the thinnest margin in the model")
print(f"  {'Regime':<10} {'es':>6} {'es_crit':>9} {'headroom':>10}")
for r in m.REGIMES:
    print(f"  {m.OMEGA[r]:<10} {m.p('es_factor', r):6.2f} {m.es_critical(r):9.4f}"
          f" {m.es_margin(r)*100:9.1f}%")
print("  The Omega = L result rests on 6.8 pct headroom in an unsourced")
print("  parameter. Disclosed in manuscript Section 4.7. Resolved; see")
print("  docs/MANUSCRIPT_CORRECTIONS.md item 5.")

# ----------------------------------------------------------------------
print("\n" + "=" * 90)
if FAILURES:
    print(f"RESULT: {len(FAILURES)} of {CHECKS} checks FAILED")
    for f in FAILURES:
        print(f"  - {f}")
    print("\nEvery failure indicates a real regression. Investigate before")
    print("submitting. See docs/MANUSCRIPT_CORRECTIONS.md for the log of")
    print("text corrections already applied.")
    sys.exit(1)
print(f"RESULT: all {CHECKS} checks passed")

# ----------------------------------------------------------------------
# Regenerate docs/NUMBER_MAP.md so the claim-to-source map cannot drift
# from the model. Previously the file was labelled auto-generated but was
# maintained by hand.
# ----------------------------------------------------------------------
try:
    from write_number_map import write_number_map
    path = write_number_map(m)
    print(f"Wrote {path}")
except Exception as exc:                                    # pragma: no cover
    print(f"WARNING: could not regenerate NUMBER_MAP.md ({exc})")

sys.exit(0)
