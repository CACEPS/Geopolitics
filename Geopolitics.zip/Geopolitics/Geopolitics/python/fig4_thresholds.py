"""
Figure 4. Capture-cost thresholds and equilibrium sensitivity.

Panel A: derived capture costs against their (S,S) flip thresholds, with
the required percentage reduction annotated. Panel B: equilibrium map
under joint scaling of both capture-cost vectors by lambda.

    python python/fig4_thresholds.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import model as m

OUT = Path(__file__).resolve().parent.parent / "outputs"
OUT.mkdir(exist_ok=True)

EQ_COLOUR = {
    "TT": "#b5443a",
    "TS": "#d98b3a",
    "ST": "#7a8ba0",
    "SS": "#2e8b57",
    "TT,SS": "#8a7fb0",
    "none": "0.85",
}
LAMBDAS = [0.50, 0.60, 0.70, 0.75, 0.80, 0.90, 1.00, 1.10, 1.25, 1.40]


def panel_a(ax) -> None:
    order = ["Baseline", "Crisis", "Boom", "WarShock"]
    y = np.arange(len(order))
    h = 0.34

    for i, r in enumerate(order):
        for off, c, star, lab, col in (
            (-h / 2, m.C_M[r], m.c_M_star(r), "Malaysia", "#2b5d7d"),
            (+h / 2, m.C_ROW[r], m.c_RoW_star(r), "Rest of World", "#d98b3a"),
        ):
            ax.barh(i + off, c, h, color=col, alpha=0.9,
                    label=lab if i == 0 else None)
            ax.plot([star], [i + off], marker="D", ms=6.5, mfc="white",
                    mec="0.12", mew=1.5, zorder=6,
                    label="(S,S) flip threshold" if i == 0 and off < 0 else None)
            ax.plot([star, star], [i + off - h / 2, i + off + h / 2],
                    color="0.12", lw=1.6, solid_capstyle="butt", zorder=5)
            fall = max(0.0, (c - star) / c) * 100
            if fall > 0:
                ax.annotate("", xy=(star, i + off), xytext=(c, i + off),
                            arrowprops=dict(arrowstyle="->", color="#8a1c14",
                                            lw=1.3, shrinkA=1, shrinkB=1),
                            zorder=7)
                txt, tc = f"{fall:.1f}% fall needed", "#8a1c14"
            else:
                txt, tc = "already below threshold", "#1d6b3f"
            ax.annotate(txt, (14.2, i + off), ha="right", va="center",
                        fontsize=8, color=tc)

    ax.set_yticks(y)
    ax.set_yticklabels([rf"$\Omega = {m.OMEGA[r]}$" for r in order])
    ax.invert_yaxis()
    ax.set_xlabel("Capture cost (payoff units); vertical rule marks the (S,S) flip threshold")
    ax.set_title("A. Derived capture costs against flip thresholds", fontsize=10.5, loc="left")
    ax.set_xlim(0, 14.6)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="x", alpha=0.25, lw=0.6)
    ax.legend(frameon=False, fontsize=9, loc="lower right")


def panel_b(ax) -> None:
    order = ["Baseline", "Crisis", "Boom", "WarShock"]
    sweep = m.lambda_sweep(LAMBDAS)
    seen = []

    for j, lam in enumerate(LAMBDAS):
        for i, r in enumerate(order):
            eq = sweep[lam][r]
            key = ",".join(eq) if eq else "none"
            col = EQ_COLOUR.get(key, "#8a7fb0")
            ax.add_patch(mpatches.Rectangle((j, i), 1, 1, facecolor=col,
                                            edgecolor="white", lw=1.4))
            ax.annotate(key.replace(",", "\n"), (j + 0.5, i + 0.5), ha="center",
                        va="center", fontsize=7.5, color="white", weight="bold")
            if key not in seen:
                seen.append(key)

    ax.set_xlim(0, len(LAMBDAS))
    ax.set_ylim(0, len(order))
    ax.set_xticks([j + 0.5 for j in range(len(LAMBDAS))])
    ax.set_xticklabels([f"{l:.2f}" for l in LAMBDAS], fontsize=8.5)
    ax.set_yticks([i + 0.5 for i in range(len(order))])
    ax.set_yticklabels([rf"$\Omega = {m.OMEGA[r]}$" for r in order])
    ax.invert_yaxis()
    ax.set_xlabel(r"$\lambda$, joint scaling factor on both capture-cost vectors")
    ax.set_title(r"B. Equilibrium map under joint capture-cost scaling",
                 fontsize=10.5, loc="left")
    idx = LAMBDAS.index(1.00)
    ax.plot([idx, idx], [0, len(order)], color="0.1", lw=2.4, ls="-")
    ax.plot([idx + 1, idx + 1], [0, len(order)], color="0.1", lw=2.4, ls="-")
    ax.annotate("point calibration", (idx + 0.5, len(order) + 0.18), ha="center",
                fontsize=8.5, color="0.15", annotation_clip=False)
    for s in ax.spines.values():
        s.set_visible(False)
    ax.tick_params(length=0)


def main() -> None:
    fig, axes = plt.subplots(1, 2, figsize=(15.0, 4.6),
                             gridspec_kw={"width_ratios": [1.0, 1.15]})
    panel_a(axes[0])
    panel_b(axes[1])
    fig.suptitle("Figure 4. Capture-cost thresholds and equilibrium sensitivity",
                 fontsize=12, y=1.03)
    fig.text(0.5, -0.10,
             "Panel A: a capture cost above its threshold rule blocks (S,S) in that regime. "
             "Panel B: cells give the pure-strategy equilibrium set at each scaling.\n"
             "The point calibration sits one step from a regime change in three of four "
             "regimes.   Source: authors' computation, python/fig4_thresholds.py",
             ha="center", fontsize=8.5, color="0.3")
    for ext in ("pdf", "png"):
        fig.savefig(OUT / f"figure4_thresholds.{ext}", dpi=300,
                    bbox_inches="tight", facecolor="white")
    print(f"wrote {OUT/'figure4_thresholds.pdf'} and .png")


if __name__ == "__main__":
    main()
