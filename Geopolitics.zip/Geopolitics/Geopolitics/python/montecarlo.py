"""
Monte Carlo over the parameters that actually bind.

Multiplicative uniform(0.75, 1.25) shocks are applied to both capture
costs and to the GSF resource stock. The full Nash test is re-run on
every draw, per regime and per GSF scenario, at the central saving rate.

Why these parameters. Equilibria depend only on payoff differences and
capture costs. Perturbing the E, I, SB and F component scores (as an
earlier version of this analysis did) cannot change any equilibrium
condition, so it measures nothing. The capture costs and the GSF pools
are the quantities the result rests on, so they are what is shocked.

Draws live in data/mc_draws.csv and are shared with the GAMS
implementation via gams/mc_draws_capture.gms. Regenerate both with
    python python/make_draws.py

    python python/montecarlo.py
"""

from __future__ import annotations

import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import model as m

DRAWS_CSV = Path(__file__).resolve().parent.parent / "data" / "mc_draws.csv"
LOW, HIGH = 0.75, 1.25


def load_draws(path: Path = DRAWS_CSV) -> dict[tuple[int, str], dict[str, float]]:
    out = {}
    with open(path, newline="", encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            out[(int(row["draw"]), row["regime"])] = {
                "cM": float(row["shock_cM"]),
                "cRoW": float(row["shock_cRoW"]),
                "pool": float(row["shock_pool"]),
            }
    return out


def run_monte_carlo(n: int = 1000, seed: int = 42) -> dict:
    """Run the Nash test over every draw.

    `seed` is retained in the signature for documentation only. Draws are
    read from disk so that the published figures reproduce exactly.
    """
    draws = load_draws()
    n = min(n, max(d for d, _ in draws))

    res = {}
    for r in m.REGIMES:
        for gsf in ("off", "on"):
            hits = m_binds = row_binds = 0
            for d in range(1, n + 1):
                sh = draws[(d, r)]
                cM = m.C_M[r] * sh["cM"]
                cR = m.C_ROW[r] * sh["cRoW"]
                if gsf == "on":
                    resources = m.GSF_RESOURCES[r] * sh["pool"]
                    cM = max(0.0, cM - m.MU_POTENCY * m.p("sigma_central") * resources)
                ok_m = cM <= m.c_M_star(r)
                ok_r = cR <= m.c_RoW_star(r)
                if ok_m and ok_r:
                    hits += 1
                else:
                    m_binds += (not ok_m)
                    row_binds += (not ok_r)
            fails = n - hits
            p_hat = hits / n
            se = (p_hat * (1 - p_hat) / n) ** 0.5
            res[(r, gsf)] = {
                "p": round(p_hat, 3),
                "ci": (round(max(0.0, p_hat - 1.96 * se), 3),
                       round(min(1.0, p_hat + 1.96 * se), 3)),
                "share_M_binds": (m_binds / fails) if fails else 0.0,
                "share_row_binds": (row_binds / fails) if fails else 0.0,
                "n": n,
            }
    return res


def main() -> None:
    res = run_monte_carlo()
    n = res[("Crisis", "on")]["n"]
    print(f"Monte Carlo over capture costs and GSF resources, N = {n:,}, seed 42")
    print(f"Multiplicative uniform({LOW}, {HIGH}) shocks; draws from data/mc_draws.csv\n")
    print(f"{'Regime':<8} {'GSF off':>8} {'95% CI':>16}   {'GSF on':>8} {'95% CI':>16}")
    for r in m.REGIMES:
        row = f"{m.OMEGA[r]:<8}"
        for g in ("off", "on"):
            d = res[(r, g)]
            row += f" {d['p']:8.3f} [{d['ci'][0]:.3f},{d['ci'][1]:.3f}]  "
        print(row)
    print("\nAmong draws where (S,S) fails with the GSF on, which side binds")
    print("(shares can exceed 100 pct because both sides can bind in one draw):")
    for r in m.STOCH_REGIMES:
        d = res[(r, "on")]
        print(f"  {m.OMEGA[r]}: Malaysia {d['share_M_binds']*100:5.1f} pct"
              f"   RoW {d['share_row_binds']*100:5.1f} pct")
    print("\nResidual risk under Omega = L is entirely RoW-side and cannot be")
    print("offset by Malaysian side payments, because the GSF acts on c_M only.")


if __name__ == "__main__":
    main()
