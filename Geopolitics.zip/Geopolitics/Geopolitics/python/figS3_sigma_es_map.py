"""
Supplementary Figure S3 (replacement).

The previous S3 mapped an expected WELFARE advantage of the (S,S) cell
over (T,T). Every cell of that grid was positive, which only restated the
Pareto ranking already in Table 2, and the GSF term entered multiplied by
p_W so GSF intensity had no effect at p_W = 0.

This replacement maps the EQUILIBRIUM region over the two parameters the
result actually rests on: the GSF saving rate sigma, which Malaysia
controls, and the energy-security factor es, which it does not. Because
the GSF acts on c_M only, a sufficiently high es blocks (S,S) at any
saving rate. The vertical frontier in each panel is that limit, and its
distance from the calibrated es value is the paper's thinnest margin.

    python python/figS3_sigma_es_map.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import ListedColormap

sys.path.insert(0, str(Path(__file__).resolve().parent))

import model as m

OUT = Path(__file__).resolve().parent.parent / "outputs"
OUT.mkdir(exist_ok=True)

PANELS = ["Crisis", "Boom", "WarShock"]
CMAP = ListedColormap(["#f2d5d2", "#cfe6da", "#2e8b57"])


def main() -> None:
    sigmas = np.linspace(0.0, 1.0, 101)
    es_vals = np.linspace(0.30, 1.60, 131)

    fig, axes = plt.subplots(1, 3, figsize=(15.0, 4.5), sharey=True)

    for ax, regime in zip(axes, PANELS):
        cRoW_star = m.c_RoW_star(regime)
        cM_star = m.c_M_star(regime)
        grid = np.zeros((len(es_vals), len(sigmas)))

        for i, es in enumerate(es_vals):
            cR = m.p("kappa_R") * m.p("fossil_sub_share") * es
            row_ok = cR <= cRoW_star
            for j, s in enumerate(sigmas):
                cM = max(0.0, m.C_M[regime]
                         - m.MU_POTENCY * s * m.GSF_RESOURCES[regime])
                m_ok = cM <= cM_star
                grid[i, j] = 2 if (row_ok and m_ok) else (1 if m_ok else 0)

        ax.imshow(grid, origin="lower", aspect="auto", cmap=CMAP, vmin=0, vmax=2,
                  extent=[sigmas[0], sigmas[-1], es_vals[0], es_vals[-1]])

        es_c = m.es_critical(regime)
        es_cal = m.p("es_factor", regime)
        s_min = m.sigma_min_analytic(regime)

        ax.axhline(es_c, color="#8a1c14", lw=1.9)
        ax.annotate(rf"$es^*$ = {es_c:.3f}", (0.02, es_c), xytext=(0, 5),
                    textcoords="offset points", fontsize=8.5, color="#8a1c14",
                    weight="bold")
        ax.axhline(es_cal, color="0.15", lw=1.6, ls="--")
        ax.annotate(rf"calibrated $es$ = {es_cal:.2f}", (0.02, es_cal),
                    xytext=(0, -12), textcoords="offset points", fontsize=8.5,
                    color="0.15")
        if s_min is not None:
            ax.axvline(s_min, color="0.15", lw=1.4, ls=":")
            ax.plot([s_min], [es_cal], "o", ms=7, mfc="white", mec="0.1", mew=1.6,
                    zorder=6)
            ax.annotate(rf"$\sigma_{{min}}$ = {s_min:.2f}", (s_min, es_vals[0]),
                        xytext=(4, 6), textcoords="offset points", fontsize=8.5,
                        color="0.15")

        head = m.es_margin(regime) * 100
        ax.set_title(rf"$\Omega = {m.OMEGA[regime]}$   headroom in $es$: {head:.1f}%",
                     fontsize=10.5)
        ax.set_xlabel(r"GSF saving rate $\sigma$")
        ax.set_xlim(0, 1)
        ax.set_ylim(es_vals[0], es_vals[-1])

    axes[0].set_ylabel(r"Energy-security factor $es(\Omega)$")

    handles = [
        plt.Rectangle((0, 0), 1, 1, fc="#2e8b57"),
        plt.Rectangle((0, 0), 1, 1, fc="#cfe6da"),
        plt.Rectangle((0, 0), 1, 1, fc="#f2d5d2"),
    ]
    axes[0].legend(handles,
                   ["(S,S) is a Nash equilibrium",
                    "Malaysia willing, RoW blocks",
                    "Malaysia blocks"],
                   frameon=False, fontsize=8.5, loc="upper right")

    fig.suptitle("Supplementary Figure S3. Equilibrium region over the GSF saving rate "
                 "and the energy-security factor", fontsize=12, y=1.03)
    fig.text(0.5, -0.09,
             "Because the GSF reduces Malaysia's capture cost only, no saving rate "
             r"recovers (S,S) once $es$ exceeds $es^*$." "\n"
             r"The $\Omega = L$ result therefore rests on 6.8 percent headroom in an "
             "assumed parameter.   Source: authors' computation, "
             "python/figS3_sigma_es_map.py",
             ha="center", fontsize=8.5, color="0.3")

    for ext in ("pdf", "png"):
        fig.savefig(OUT / f"figureS3_sigma_es_map.{ext}", dpi=300,
                    bbox_inches="tight", facecolor="white")
    print(f"wrote {OUT/'figureS3_sigma_es_map.pdf'} and .png")


if __name__ == "__main__":
    main()
