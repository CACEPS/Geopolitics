"""Sensitivity of every equilibrium claim to the fuel subsidy calibration input.

Why this script exists
----------------------
`data/fiscal_inputs.csv` carries a fuel subsidy bill for each regime. That
figure enters the rent exposure ratio, which sets c_M, which is reported in
manuscript Table 3. It is therefore a live calibration input, not a narrative
figure.

The baseline value of MYR 20 billion per year is the least well sourced input
in the model. Malaysian subsidy figures vary by a factor of three or more
depending on scope: petroleum products alone, plus electricity and ICPT
compensation, or the full Ministry of Finance "Subsidies and Social Assistance"
line, which also contains non-energy cash transfers. See
docs/DATA_PROVENANCE.md.

Rather than assert a figure we cannot source, this script establishes what the
uncertainty does and does not change. Run it and report the result.

Usage
-----
    python python/sensitivity_subsidy.py
"""

from __future__ import annotations

import csv
import importlib
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FISCAL_CSV = ROOT / "data" / "fiscal_inputs.csv"
sys.path.insert(0, str(ROOT / "python"))

# Multipliers applied to the subsidy column in every regime simultaneously.
# 1.0 is the shipped calibration. 3.0 spans the full plausible scope range.
SCALES = [0.7, 1.0, 1.5, 2.0, 2.5, 3.0]

REGIME_ORDER = ["Baseline", "Crisis", "Boom", "WarShock"]


def _scaled_rows(rows: list[dict], factor: float) -> list[dict]:
    out = []
    for row in rows:
        new = dict(row)
        if new["regime"] in REGIME_ORDER:
            new["subsidy_bill_myr_bn"] = str(
                round(float(row["subsidy_bill_myr_bn"]) * factor, 2)
            )
        out.append(new)
    return out


def _write(rows: list[dict], fieldnames: list[str], path: Path) -> None:
    with path.open("w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames, quoting=csv.QUOTE_MINIMAL)
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    with FISCAL_CSV.open() as fh:
        reader = csv.DictReader(fh)
        original_rows = list(reader)
        fieldnames = list(reader.fieldnames or [])

    backup = FISCAL_CSV.with_suffix(".csv.bak")
    shutil.copy2(FISCAL_CSV, backup)

    print("=" * 78)
    print(" Sensitivity of equilibrium claims to the fuel subsidy input")
    print("=" * 78)
    print()
    print(" The subsidy column is scaled in all four regimes at once. The two")
    print(" quantities that matter are sigma_min in the boom regime, which is")
    print(" the headline policy threshold, and the equilibrium set itself.")
    print()
    print(f" {'scale':>6} {'baseline':>9} {'c_M(B)':>8} {'c_M/c_M*':>9}"
          f" {'sig_min(H)':>11} {'NE B':>6} {'NE H+GSF':>9} {'NE L+GSF':>9}")
    print(" " + "-" * 74)

    rows_out = []
    try:
        for factor in SCALES:
            _write(_scaled_rows(original_rows, factor), fieldnames, FISCAL_CSV)

            for mod in ("model",):
                if mod in sys.modules:
                    del sys.modules[mod]
            m = importlib.import_module("model")

            sub_b = float(m.FISCAL["Baseline"]["subsidy_bill_myr_bn"])
            c_m_b = m.capture_cost_M("Baseline")
            ratio_b = m.cost_ratio("Baseline", "M")
            smin_h = m.sigma_min_analytic("Boom")
            ne_b = ",".join(m.equilibria("Baseline", m.default_costs("Baseline", False)))
            ne_h = ",".join(m.equilibria("Boom", m.default_costs("Boom", True)))
            ne_l = ",".join(m.equilibria("Crisis", m.default_costs("Crisis", True)))

            flag = "  <-- shipped" if factor == 1.0 else ""
            print(f" {factor:>6.1f} {sub_b:>9.1f} {c_m_b:>8.3f} {ratio_b:>9.3f}"
                  f" {smin_h:>11.4f} {ne_b:>6} {ne_h:>9} {ne_l:>9}{flag}")
            rows_out.append((factor, smin_h, ne_b, ne_h, ne_l))
    finally:
        shutil.move(str(backup), str(FISCAL_CSV))

    sigma_central = 0.6
    print()
    print(" Reading of the result")
    print(" " + "-" * 74)

    all_hold = all(ne_h == "SS" and ne_l == "SS" and ne_b == "TT"
                   for _, _, ne_b, ne_h, ne_l in rows_out)
    smin_max = max(s for _, s, *_ in rows_out)

    if all_hold:
        print(" Every equilibrium claim in Table 3 survives the full range tested.")
        print(" The baseline stays at (T,T). The boom and crisis regimes still flip")
        print(" to (S,S) under the fund at the central saving rate.")
    else:
        print(" WARNING: at least one equilibrium changed. Inspect the table above.")

    print(f" sigma_min in the boom regime rises to at most {smin_max:.4f} across the")
    print(f" range, against a central saving rate of {sigma_central}. The margin")
    print(f" narrows from {sigma_central - rows_out[SCALES.index(1.0)][1]:.3f} to"
          f" {sigma_central - smin_max:.3f} but does not close.")
    print()
    print(" Conclusion for the manuscript: the subsidy figure is the least well")
    print(" sourced input, but no equilibrium claim depends on resolving it. The")
    print(" reported c_M levels do depend on it, so Table 3 must be regenerated")
    print(" if the calibration changes. See docs/DATA_PROVENANCE.md.")
    print()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
