#!/usr/bin/env bash
# Reproduce every computed result in the paper.
set -euo pipefail
cd "$(dirname "$0")"

echo "=============================================================="
echo " 1/4  Verifying all published numbers against the model"
echo "=============================================================="
python3 python/verify.py

echo
echo "=============================================================="
echo " 2/4  Monte Carlo robustness (N = 1,000 per regime, seed 42)"
echo "=============================================================="
python3 python/montecarlo.py

echo
echo "=============================================================="
echo " 3/4  Sensitivity to the fuel subsidy calibration input"
echo "=============================================================="
python3 python/sensitivity_subsidy.py

echo
echo "=============================================================="
echo " 4/4  Regenerating figures into outputs/"
echo "=============================================================="
python3 python/fig3_net_payoffs.py
python3 python/fig4_thresholds.py
python3 python/figS3_sigma_es_map.py

echo
echo "Done."
echo "  outputs/                       figures"
echo "  docs/NUMBER_MAP.md             claim-to-source map, regenerated above"
echo "  docs/DATA_PROVENANCE.md        how well sourced each input is"
echo "  docs/MANUSCRIPT_CORRECTIONS.md outstanding and resolved text edits"
