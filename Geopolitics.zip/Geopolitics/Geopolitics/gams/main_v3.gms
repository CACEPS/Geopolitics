$TITLE Malaysia Energy Geopolitics: Game-Theoretic Analysis (R1 model, v3)
* ====================================================================
* Oil Market Crises, Macro-Fiscal Policy and Sustainable Futures:
* Distributive Conflict in Malaysia's Energy Geopolitics
*
* Players     : Malaysia (M), Rest of World (RoW)
* Strategies  : Traditional (T), Sustainable (S)
* Regimes     : Baseline (B), Crisis (L), Boom (H), WarShock (W)
*
*   Pi_net_i = Pi_gross_i - c_i(Omega) * 1[s_i = S]
*
* Gross payoffs are COMPUTED from the Section 3.5 component calibration.
* Capture costs are DERIVED from fiscal observables. The GSF enters as an
* exogenous policy instrument with saving rate sigma.
*
* CHANGES FROM v2
*   1. RoW energy-security premium moved out of the SB component, so every
*      component score now lies inside its declared 0 to 20 bound.
*   2. Module 9 allocation uses gsf_resources, not windfall_pool. The two
*      differ at Crisis, where the pool is zero but the fund disburses the
*      boom-accumulated stock.
*   3. sigma_min solved in closed form, so the reported minimum is not an
*      artefact of the sweep resolution.
*   4. Scale-free cost ratios c/c* added. These are invariant to kappa_M
*      and kappa_R, so equilibrium claims do not depend on either constant.
*   5. es(Omega) critical values and headroom added. This is the thinnest
*      margin in the model and it is now reported.
*   6. Dominance solvability computed, which is the precise criterion for
*      the 'regime-dominant' label in Table 2.
*   7. Calibration check comment restated honestly (see Module 3).
* ====================================================================

* ================= MODULE 1: SETS ===================================

SET players    / Malaysia, RoW /;
SET strategies / Traditional, Sustainable /;
SET regimes    / Baseline, Crisis, Boom, WarShock /;
SET outcomes   / TT, TS, ST, SS /;
SET dims       / E, I, SB, F /;
ALIAS(outcomes, outcomes2);

* Stochastic regimes for probability-weighted expectations (Section 3.8:
* p_L = 0.45, p_H = 0.35, p_W = 0.20). Baseline is the empirical anchor
* and is deliberately excluded from the forecast distribution.
SET stoch_regimes(regimes) / Crisis, Boom, WarShock /;

* Unilateral deviation maps.
SET dev_M(outcomes, outcomes) / TT.ST, ST.TT, TS.SS, SS.TS /;
SET dev_R(outcomes, outcomes) / TT.TS, TS.TT, ST.SS, SS.ST /;

PARAMETER plays_S(outcomes, players) "Does the player select S here?"
         / TT.Malaysia 0, TT.RoW 0
           TS.Malaysia 0, TS.RoW 1
           ST.Malaysia 1, ST.RoW 0
           SS.Malaysia 1, SS.RoW 1 /;

* ================= MODULE 2: COMPONENT CALIBRATION ==================
* Component scores on a 0 to 20 min-max normalised scale, reported to
* the nearest 0.2. Mirrors data/components.csv.
*   E  economic performance      (enters positively)
*   I  environmental impact      (enters negatively)
*   SB sustainability benefit    (enters positively; global public good,
*                                 so larger for RoW)
*   F  macro-fiscal performance  (enters positively)
*
* The RoW energy-security premium under Omega = W is NOT folded into SB.
* It is a separate additive term (see es_premium below), which keeps all
* component scores inside the declared 0 to 20 bound.

PARAMETER weights(dims) "Payoff weights (baseline = equal weighting)"
         / E 0.25, I 0.25, SB 0.25, F 0.25 /;

TABLE components(regimes, outcomes, players, dims) "Section 3.5 component scores"
                                E      I     SB      F
Baseline.TT.Malaysia           10     12      2      4
Baseline.TT.RoW                 9     13      2      6
Baseline.TS.Malaysia           10     12      6      8
Baseline.TS.RoW                12      6      8     20
Baseline.ST.Malaysia            8      5      6     19
Baseline.ST.RoW                 9     13      8     10
Baseline.SS.Malaysia            8      5     13     20
Baseline.SS.RoW                12      6     20     18
Crisis.TT.Malaysia              4     10      2      2
Crisis.TT.RoW                   5     11      2      6
Crisis.TS.Malaysia              4     10      6      6
Crisis.TS.RoW                  12      5      8     15
Crisis.ST.Malaysia              6      4      6     14
Crisis.ST.RoW                   5     11      8      8
Crisis.SS.Malaysia              6      4     13     19
Crisis.SS.RoW                  12      5     20     19
Boom.TT.Malaysia               14     14      2      9.2
Boom.TT.RoW                    10     14      2      5.2
Boom.TS.Malaysia               14     14      6     12
Boom.TS.RoW                    12      6      8     20
Boom.ST.Malaysia               10      6      6     16
Boom.ST.RoW                    10     14      8      8
Boom.SS.Malaysia               10      6     13     19
Boom.SS.RoW                    12      6     20     18
WarShock.TT.Malaysia           12     12      2      6
WarShock.TT.RoW                 6     13      2      3
WarShock.TS.Malaysia           12     12      6     10
WarShock.TS.RoW                12      5      8     11
WarShock.ST.Malaysia           14      5      6     11
WarShock.ST.RoW                 6     13      8      1
WarShock.SS.Malaysia           14      5     13     20
WarShock.SS.RoW                12      5     20     19
;

* Bound check: every component score must lie inside 0 to 20.
SCALAR comp_min, comp_max;
comp_min = SMIN((regimes, outcomes, players, dims), components(regimes, outcomes, players, dims));
comp_max = SMAX((regimes, outcomes, players, dims), components(regimes, outcomes, players, dims));
ABORT$(comp_min < 0 OR comp_max > 20)
    "Component score outside the declared 0 to 20 bound", comp_min, comp_max;

* RoW energy-security premium, additive and outside the components.
SCALAR es_premium "RoW energy-security premium under Omega = W" / 4.0 /;
PARAMETER premium(regimes, players);
premium(regimes, players) = 0;
premium('WarShock', 'RoW') = es_premium;

* ================= MODULE 3: COMPUTED GROSS PAYOFF MATRIX ===========

PARAMETER payoff_M(regimes, outcomes), payoff_RoW(regimes, outcomes);
payoff_M(regimes, outcomes) =
      weights('E')  * components(regimes, outcomes, 'Malaysia', 'E')
    - weights('I')  * components(regimes, outcomes, 'Malaysia', 'I')
    + weights('SB') * components(regimes, outcomes, 'Malaysia', 'SB')
    + weights('F')  * components(regimes, outcomes, 'Malaysia', 'F')
    + weights('SB') * premium(regimes, 'Malaysia');
payoff_RoW(regimes, outcomes) =
      weights('E')  * components(regimes, outcomes, 'RoW', 'E')
    - weights('I')  * components(regimes, outcomes, 'RoW', 'I')
    + weights('SB') * components(regimes, outcomes, 'RoW', 'SB')
    + weights('F')  * components(regimes, outcomes, 'RoW', 'F')
    + weights('SB') * premium(regimes, 'RoW');

* --------------------------------------------------------------------
* REGRESSION GUARD, NOT A VALIDATION TEST.
*
* The component scores above are a DECOMPOSITION of the published Table 2
* matrix, not an independent derivation from raw indicators. This check
* therefore confirms two things only: that the decomposition is
* transcribed correctly, and that no later edit silently shifts a
* headline payoff. It does not validate the calibration against data.
*
* Its scientific purpose is auditability. A reader can see which of the
* four dimensions drives each payoff difference, which is what the
* transparency comment on calibration asked for.
* --------------------------------------------------------------------

TABLE table2_published(regimes, outcomes, players) "Table 2 gross payoffs"
                    Malaysia      RoW
Baseline.TT           1.0          1.0
Baseline.TS           3.0          8.5
Baseline.ST           7.0          3.5
Baseline.SS           9.0         11.0
Crisis.TT            -0.5          0.5
Crisis.TS             1.5          7.5
Crisis.ST             5.5          2.5
Crisis.SS             8.5         11.5
Boom.TT               2.8          0.8
Boom.TS               4.5          8.5
Boom.ST               6.5          3.0
Boom.SS               9.0         11.0
WarShock.TT           2.0          0.5
WarShock.TS           4.0          7.5
WarShock.ST           6.5          1.5
WarShock.SS          10.5         12.5
;

SCALAR max_calib_error;
max_calib_error = MAX(
    SMAX((regimes, outcomes), ABS(payoff_M(regimes, outcomes)   - table2_published(regimes, outcomes, 'Malaysia'))),
    SMAX((regimes, outcomes), ABS(payoff_RoW(regimes, outcomes) - table2_published(regimes, outcomes, 'RoW'))));
ABORT$(max_calib_error > 1e-9)
    "Computed payoffs no longer reproduce Table 2", max_calib_error;

* ================= MODULE 4: COMPONENT DECOMPOSITION ================
* Reported so the contribution of each dimension is auditable per cell.

PARAMETER contribution(regimes, outcomes, players, dims);
contribution(regimes, outcomes, players, 'E')  =  weights('E')  * components(regimes, outcomes, players, 'E');
contribution(regimes, outcomes, players, 'I')  = -weights('I')  * components(regimes, outcomes, players, 'I');
contribution(regimes, outcomes, players, 'SB') =  weights('SB') * components(regimes, outcomes, players, 'SB');
contribution(regimes, outcomes, players, 'F')  =  weights('F')  * components(regimes, outcomes, players, 'F');

* ================= MODULE 5: DERIVED CAPTURE COSTS ==================
* Malaysia: c_M(Omega) = kappa_M * RER(Omega) * [1 + lambda_d * d(Omega)]
*   RER = (fuel subsidy bill + discretionary petroleum revenue)
*         / federal revenue                    [rent-exposure ratio]
*   d   = fiscal deficit, percent of GDP       [fiscal-stress amplifier]
* Fiscal inputs are stylised approximations from published sources
* (MoF Malaysia 2023 2024; Petronas 2023; IMF 2016 2021 2024) and mirror
* data/fiscal_inputs.csv.

PARAMETER fed_revenue(regimes)  "Federal revenue, MYR bn"
         / Baseline 300, Crisis 260, Boom 335, WarShock 360 /;
PARAMETER subsidy_bill(regimes) "Fuel subsidy bill, MYR bn"
         / Baseline 20,  Crisis 14,  Boom 28,  WarShock 38 /;
PARAMETER petro_revenue(regimes) "Discretionary petroleum revenue, MYR bn"
         / Baseline 78,  Crisis 52,  Boom 107, WarShock 130 /;
PARAMETER deficit_gdp(regimes)  "Fiscal deficit, percent of GDP"
         / Baseline 5.0, Crisis 6.8, Boom 2.5, WarShock 4.0 /;

SCALAR kappa_M   "Scaling constant, Malaysia"    / 16.0 /;
SCALAR lambda_d  "Fiscal-stress amplifier slope" / 0.12 /;

PARAMETER RER(regimes), stress_A(regimes), capture_cost_M(regimes);
RER(regimes)      = (subsidy_bill(regimes) + petro_revenue(regimes)) / fed_revenue(regimes);
stress_A(regimes) = 1 + lambda_d * deficit_gdp(regimes);
capture_cost_M(regimes) = kappa_M * RER(regimes) * stress_A(regimes);

* RoW: c_RoW(Omega) = kappa_R * post-tax fossil subsidy share of world
* GDP (Coady et al. 2015: 0.065) * energy-security factor es(Omega).
* es > 1 when cheap oil entrenches fossil consumption interests in
* importing economies; es < 1 when high prices or supply insecurity
* convert fossil dependence into a security liability.

SCALAR kappa_R          "Scaling constant, RoW" / 120   /;
SCALAR fossil_sub_share "Post-tax subsidy share of world GDP" / 0.065 /;
PARAMETER es_factor(regimes) "Energy-security factor"
         / Baseline 1.00, Crisis 1.08, Boom 0.93, WarShock 0.45 /;
PARAMETER capture_cost_RoW(regimes);
capture_cost_RoW(regimes) = kappa_R * fossil_sub_share * es_factor(regimes);

* ================= MODULE 6: GSF POLICY INSTRUMENT ==================
* Windfall pool, USD bn over a 24-month window:
*   pool = premium above the USD 80/bbl trigger
*          x oil-equivalent exports (0.9 mboe/d: ~25 mtpa Bintulu LNG
*            plus crude and condensate)
*          x 30.4 days x 24 months / 1000
*          x fiscal capture share (0.61)
* Boom premium USD 27.5/bbl (2011-13 mean ~107.5 less the 80 trigger).
* WarShock premium USD 55/bbl (stylised 135 less 80). The trigger never
* fires at Baseline or Crisis, so the Crisis-period fund disburses the
* stock accumulated in the preceding boom (counter-cyclical drawdown).

SCALAR vol_mboed      / 0.9  /;
SCALAR window_months  / 24   /;
SCALAR fiscal_capture / 0.61 /;
PARAMETER price_premium(regimes)
         / Baseline 0, Crisis 0, Boom 27.5, WarShock 55 /;
PARAMETER windfall_pool(regimes);
windfall_pool(regimes) = ROUND(price_premium(regimes) * vol_mboed * 30.4
                               * window_months / 1000 * fiscal_capture, 1);

PARAMETER gsf_resources(regimes) "Resources available for side payments, USD bn";
gsf_resources('Baseline') = 0;
gsf_resources('Boom')     = windfall_pool('Boom');
gsf_resources('Crisis')   = windfall_pool('Boom');
gsf_resources('WarShock') = windfall_pool('WarShock');

* Side-payment potency mu, payoff units per USD bn deployed. Anchored so
* that full deployment of the WarShock pool at the central saving rate
* exactly neutralises the war-regime capture cost.
SCALAR sigma_central "Central GSF saving rate (policy instrument)" / 0.6 /;
SCALAR mu_potency;
mu_potency = ROUND(capture_cost_M('WarShock') / (sigma_central * windfall_pool('WarShock')), 2);

* Full 2 x 4 factorial: GSF off and on in every regime.
SET gsf / off, on /;
PARAMETER gsf_active(gsf) / off 0, on 1 /;

PARAMETER c_M_eff(regimes, gsf);
c_M_eff(regimes, gsf) = MAX(0, capture_cost_M(regimes)
      - gsf_active(gsf) * mu_potency * sigma_central * gsf_resources(regimes));

* ================= MODULE 7: NASH EQUILIBRIA ========================
* Full enumeration on net payoffs. The capture cost is paid whenever the
* player selects S, in any outcome.

PARAMETER net_M(regimes, outcomes, gsf), net_RoW(regimes, outcomes, gsf);
net_M(regimes, outcomes, gsf)   = payoff_M(regimes, outcomes)
      - plays_S(outcomes, 'Malaysia') * c_M_eff(regimes, gsf);
net_RoW(regimes, outcomes, gsf) = payoff_RoW(regimes, outcomes)
      - plays_S(outcomes, 'RoW') * capture_cost_RoW(regimes);

PARAMETER is_NE(regimes, outcomes, gsf);
is_NE(regimes, outcomes, gsf)$(
        net_M(regimes, outcomes, gsf)
          >= SUM(dev_M(outcomes, outcomes2), net_M(regimes, outcomes2, gsf))
    AND net_RoW(regimes, outcomes, gsf)
          >= SUM(dev_R(outcomes, outcomes2), net_RoW(regimes, outcomes2, gsf))
    ) = 1;

PARAMETER regime_prob(regimes)
         / Crisis 0.45, Boom 0.35, WarShock 0.20, Baseline 0 /;
PARAMETER prob_SS_equilibrium(gsf);
prob_SS_equilibrium(gsf) =
    SUM(regimes$stoch_regimes(regimes), is_NE(regimes,'SS',gsf) * regime_prob(regimes));

* Dominance solvability. S is strictly dominant for a player when it
* beats T against BOTH opponent actions. This is the precise criterion
* for the 'regime-dominant' label used in Table 2.
PARAMETER S_dominant_M(regimes, gsf), S_dominant_RoW(regimes, gsf),
          SS_dominance_solvable(regimes, gsf);
S_dominant_M(regimes, gsf)$(
        net_M(regimes,'ST',gsf) > net_M(regimes,'TT',gsf)
    AND net_M(regimes,'SS',gsf) > net_M(regimes,'TS',gsf)) = 1;
S_dominant_RoW(regimes, gsf)$(
        net_RoW(regimes,'TS',gsf) > net_RoW(regimes,'TT',gsf)
    AND net_RoW(regimes,'SS',gsf) > net_RoW(regimes,'ST',gsf)) = 1;
SS_dominance_solvable(regimes, gsf) =
    S_dominant_M(regimes, gsf) * S_dominant_RoW(regimes, gsf);

* ================= MODULE 8: THRESHOLDS, RATIOS, LAMBDA =============
*   c_M*   = Pi_M(S,S)   - Pi_M(T,S)
*   c_RoW* = Pi_RoW(S,S) - Pi_RoW(S,T)

PARAMETER c_M_star(regimes), c_RoW_star(regimes),
          required_fall_M(regimes), required_fall_RoW(regimes),
          ratio_M(regimes), ratio_RoW(regimes);
c_M_star(regimes)   = payoff_M(regimes,'SS')   - payoff_M(regimes,'TS');
c_RoW_star(regimes) = payoff_RoW(regimes,'SS') - payoff_RoW(regimes,'ST');
required_fall_M(regimes)   = MAX(0, (capture_cost_M(regimes)   - c_M_star(regimes))   / capture_cost_M(regimes));
required_fall_RoW(regimes) = MAX(0, (capture_cost_RoW(regimes) - c_RoW_star(regimes)) / capture_cost_RoW(regimes));

* Scale-free ratios. Invariant to kappa_M and kappa_R, so every
* equilibrium claim below is independent of both scaling constants.
ratio_M(regimes)   = capture_cost_M(regimes)   / c_M_star(regimes);
ratio_RoW(regimes) = capture_cost_RoW(regimes) / c_RoW_star(regimes);

* Critical es(Omega): the value at which c_RoW exactly meets its flip
* threshold. Above it the RoW side blocks (S,S) at ANY saving rate,
* because the GSF acts on c_M only. The headroom at Omega = L is the
* thinnest margin in the model.
PARAMETER es_critical(regimes), es_headroom(regimes);
es_critical(regimes) = c_RoW_star(regimes) / (kappa_R * fossil_sub_share);
es_headroom(regimes) = (es_critical(regimes) - es_factor(regimes)) / es_factor(regimes);

* Lambda sweep: scale both capture-cost vectors jointly, GSF off.
SET lgrid / l1*l10 /;
PARAMETER lambda_val(lgrid)
         / l1 0.50, l2 0.60, l3 0.70, l4 0.75, l5 0.80
           l6 0.90, l7 1.00, l8 1.10, l9 1.25, l10 1.40 /;
PARAMETER is_NE_lambda(lgrid, regimes, outcomes);
is_NE_lambda(lgrid, regimes, outcomes)$(
        payoff_M(regimes, outcomes)
          - plays_S(outcomes,'Malaysia') * lambda_val(lgrid) * capture_cost_M(regimes)
      >= SUM(dev_M(outcomes, outcomes2), payoff_M(regimes, outcomes2)
          - plays_S(outcomes2,'Malaysia') * lambda_val(lgrid) * capture_cost_M(regimes))
    AND payoff_RoW(regimes, outcomes)
          - plays_S(outcomes,'RoW') * lambda_val(lgrid) * capture_cost_RoW(regimes)
      >= SUM(dev_R(outcomes, outcomes2), payoff_RoW(regimes, outcomes2)
          - plays_S(outcomes2,'RoW') * lambda_val(lgrid) * capture_cost_RoW(regimes))
    ) = 1;

* ================= MODULE 9: SAVING RATE SIGMA ======================
* sigma_min is solved in CLOSED FORM, not read off a grid, so the
* reported minimum is not an artefact of the sweep resolution.
*
*   (S,S) requires  c_M - mu*sigma*G  <=  c_M*   and   c_RoW <= c_RoW*
*   hence           sigma >= (c_M - c_M*) / (mu*G)
*
* row_blocks = 1 marks regimes where no saving rate can work, because
* the RoW side is above its threshold and the GSF acts on c_M only.

PARAMETER row_blocks(regimes), sigma_min(regimes), sigma_feasible(regimes);
row_blocks(regimes)$(capture_cost_RoW(regimes) > c_RoW_star(regimes)) = 1;
sigma_min(regimes)$(
        row_blocks(regimes) = 0
    AND mu_potency * gsf_resources(regimes) > 0) =
    MAX(0, (capture_cost_M(regimes) - c_M_star(regimes))
           / (mu_potency * gsf_resources(regimes)));
sigma_feasible(regimes)$(
        row_blocks(regimes) = 0
    AND mu_potency * gsf_resources(regimes) > 0
    AND sigma_min(regimes) <= 1) = 1;

* Gridded sweep retained for display only.
SET sgrid / s1*s21 /;
PARAMETER sigma_val(sgrid);
sigma_val(sgrid) = (ORD(sgrid)-1) * 0.05;

* Deployed resources use gsf_resources, NOT windfall_pool. The two differ
* at Crisis, where the pool is zero but the fund draws down the
* boom-accumulated stock. (This was a defect in v2.)
PARAMETER GSF_allocation_green(sgrid, regimes);
GSF_allocation_green(sgrid, regimes) = gsf_resources(regimes) * sigma_val(sgrid);

PARAMETER allocation_at_sigma_min(regimes);
allocation_at_sigma_min(regimes)$sigma_feasible(regimes) =
    gsf_resources(regimes) * sigma_min(regimes);

* ================= MODULE 10: WELFARE ===============================
* Expected-payoff comparisons of the (S,S) and (T,T) cells are WELFARE
* comparisons of two outcomes. They carry no information about
* equilibrium selection, which is Module 7.

PARAMETER welfare_combined(regimes, outcomes), efficiency_gap(regimes);
welfare_combined(regimes, outcomes) = payoff_M(regimes, outcomes) + payoff_RoW(regimes, outcomes);
efficiency_gap(regimes) = welfare_combined(regimes,'SS') - welfare_combined(regimes,'TT');

PARAMETER exp_welfare(outcomes, players);
exp_welfare(outcomes,'Malaysia') = SUM(regimes$stoch_regimes(regimes),
      regime_prob(regimes) * payoff_M(regimes, outcomes));
exp_welfare(outcomes,'RoW')      = SUM(regimes$stoch_regimes(regimes),
      regime_prob(regimes) * payoff_RoW(regimes, outcomes));

* ================= RESULTS ==========================================

DISPLAY payoff_M, payoff_RoW, contribution, capture_cost_M, capture_cost_RoW,
        RER, stress_A, es_factor, windfall_pool, gsf_resources, mu_potency,
        c_M_eff, is_NE, SS_dominance_solvable, prob_SS_equilibrium,
        c_M_star, c_RoW_star, required_fall_M, required_fall_RoW,
        ratio_M, ratio_RoW, es_critical, es_headroom, is_NE_lambda,
        sigma_min, sigma_feasible, allocation_at_sigma_min,
        GSF_allocation_green, welfare_combined, efficiency_gap, exp_welfare;

FILE results / results_main_v3.txt /;
PUT results;
PUT "======================================================================" /;
PUT "MALAYSIA ENERGY GEOPOLITICS: R1 MODEL RESULTS (v3)"                     /;
PUT "======================================================================" /;
PUT " " /;
PUT "REGRESSION GUARD: max |computed - Table 2| = ", max_calib_error:12:10 /;
PUT "  (confirms the decomposition is transcribed correctly; it is not an" /;
PUT "   independent validation of the calibration against data)" /;
PUT "COMPONENT BOUNDS: min = ", comp_min:5:1, "  max = ", comp_max:5:1,
    "  (declared range 0 to 20)" /;
PUT " " /;
PUT "DERIVED CAPTURE COSTS (Section 3.5.3)" /;
LOOP(regimes,
    PUT regimes.TL:10, "  c_M = ", capture_cost_M(regimes):6:2,
        "  c_RoW = ", capture_cost_RoW(regimes):6:2,
        "   (RER = ", RER(regimes):6:4, ", A = ", stress_A(regimes):5:3, ")" /;
);
PUT " " /;
PUT "NASH EQUILIBRIA, FULL 2 x 4 GSF FACTORIAL (Table 3)" /;
LOOP(gsf,
    PUT "  GSF ", gsf.TL:4 /;
    LOOP(regimes,
        PUT "    ", regimes.TL:10;
        LOOP(outcomes$is_NE(regimes, outcomes, gsf), PUT "  ", outcomes.TL:4, " is NE");
        PUT$(SUM(outcomes$is_NE(regimes,outcomes,gsf), 1) = 0) "  no pure-strategy NE";
        PUT$SS_dominance_solvable(regimes, gsf) "   [S strictly dominant for both]";
        PUT /;
    );
);
PUT " " /;
PUT "P[(S,S) is NE], regime weighted:  GSF off = ", prob_SS_equilibrium('off'):6:3,
    "   GSF on = ", prob_SS_equilibrium('on'):6:3 /;
PUT " " /;
PUT "FLIP THRESHOLDS, REQUIRED FALLS AND SCALE-FREE RATIOS" /;
PUT "Regime      c_M   c_M*   fall%    c/c*  |  c_RoW  c_RoW*   fall%    c/c*" /;
LOOP(regimes,
    PUT regimes.TL:10, capture_cost_M(regimes):7:2, c_M_star(regimes):7:2,
        (required_fall_M(regimes)*100):8:1, ratio_M(regimes):8:3, "  |",
        capture_cost_RoW(regimes):7:2, c_RoW_star(regimes):8:2,
        (required_fall_RoW(regimes)*100):8:1, ratio_RoW(regimes):8:3 /;
);
PUT "  c/c* is invariant to kappa_M and kappa_R. Ratios above 1 block (S,S)." /;
PUT " " /;
PUT "ENERGY-SECURITY FACTOR FRAGILITY" /;
PUT "Regime        es   es_crit   headroom%" /;
LOOP(regimes,
    PUT regimes.TL:10, es_factor(regimes):7:2, es_critical(regimes):10:4,
        (es_headroom(regimes)*100):11:1 /;
);
PUT "  Above es_crit the RoW side blocks (S,S) at ANY saving rate," /;
PUT "  because the GSF reduces c_M only. Omega = L has the least headroom." /;
PUT " " /;
PUT "MINIMUM SAVING RATE (closed form, not gridded)" /;
LOOP(regimes$stoch_regimes(regimes),
    PUT regimes.TL:10;
    PUT$(row_blocks(regimes) = 1) "  RoW side blocks; no sigma suffices" /;
    PUT$(row_blocks(regimes) = 0) "  sigma_min = ", sigma_min(regimes):6:3,
        "   deploys USD ", allocation_at_sigma_min(regimes):6:2, " bn" /;
);
PUT " " /;
PUT "EFFICIENCY GAPS AND EXPECTED WELFARE (gross, stochastic regimes)" /;
LOOP(regimes, PUT regimes.TL:10, ": gap = ", efficiency_gap(regimes):6:2 /; );
PUT "  E[pi(S,S)]  M: ", exp_welfare('SS','Malaysia'):7:3, "  RoW: ", exp_welfare('SS','RoW'):7:3 /;
PUT "  E[pi(T,T)]  M: ", exp_welfare('TT','Malaysia'):7:3, "  RoW: ", exp_welfare('TT','RoW'):7:3 /;
PUT "  Welfare comparison of two cells. Equilibrium selection is Module 7." /;
CLOSE results;

* ================= END OF MODEL =====================================
