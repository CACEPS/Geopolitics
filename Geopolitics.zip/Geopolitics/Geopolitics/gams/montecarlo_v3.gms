$TITLE Malaysia Energy Geopolitics: Monte Carlo over Capture Costs (v3)
* ====================================================================
* Monte Carlo robustness for Section 4.7.
*
* N = 1,000 draws apply multiplicative uniform(0.75, 1.25) shocks to the
* derived capture costs c_M(Omega) and c_RoW(Omega) and to the GSF
* resource stock. For every draw the full Nash test of main_v3.gms is
* re-run, per regime and per GSF scenario, at sigma = 0.6.
*
* WHY THESE PARAMETERS. Equilibria depend only on payoff differences and
* capture costs. Perturbing the E, I, SB and F component scores cannot
* change any equilibrium condition, so it measures nothing. The capture
* costs and the GSF pools are what the result rests on.
*
* Draws are pre-generated (numpy default_rng, seed 42) and shipped in
* mc_draws_capture.gms so results are exactly reproducible. The same
* draws are mirrored in data/mc_draws.csv for the Python implementation.
* Regenerate both with: python python/make_draws.py
*
* NEW IN v3: reports WHICH SIDE binds on the failing draws. This matters
* because the GSF acts on c_M only, so RoW-side failures cannot be
* offset by Malaysian side payments at any saving rate.
* ====================================================================

SET regimes  / Baseline, Crisis, Boom, WarShock /;
SET outcomes / TT, TS, ST, SS /;
SET players  / Malaysia, RoW /;
SET gsf      / off, on /;
SET sim      / sim1*sim1000 /;
ALIAS(outcomes, outcomes2);

SET stoch_regimes(regimes) / Crisis, Boom, WarShock /;
SET dev_M(outcomes, outcomes) / TT.ST, ST.TT, TS.SS, SS.TS /;
SET dev_R(outcomes, outcomes) / TT.TS, TS.TT, ST.SS, SS.ST /;
PARAMETER plays_S(outcomes, players)
         / TT.Malaysia 0, TT.RoW 0
           TS.Malaysia 0, TS.RoW 1
           ST.Malaysia 1, ST.RoW 0
           SS.Malaysia 1, SS.RoW 1 /;

* Gross payoffs, identical to the computed matrix of main_v3.gms.
TABLE payoff(regimes, outcomes, players)
                    Malaysia      RoW
Baseline.TT           1.0          1.0
Baseline.TS           3.0          8.5
Baseline.ST           7.0          3.5
Baseline.SS           9.0         11.0
Crisis.TT            -0.5          0.5
Crisis.TS             1.5          7.5
Crisis.ST             5.5          2.5
Crisis.SS             8.5         11.5
Boom.TT               2.8          0.8
Boom.TS               4.5          8.5
Boom.ST               6.5          3.0
Boom.SS               9.0         11.0
WarShock.TT           2.0          0.5
WarShock.TS           4.0          7.5
WarShock.ST           6.5          1.5
WarShock.SS          10.5         12.5
;
PARAMETER payoff_M(regimes, outcomes), payoff_RoW(regimes, outcomes);
payoff_M(regimes, outcomes)   = payoff(regimes, outcomes, 'Malaysia');
payoff_RoW(regimes, outcomes) = payoff(regimes, outcomes, 'RoW');

PARAMETER c_M_star(regimes), c_RoW_star(regimes);
c_M_star(regimes)   = payoff_M(regimes,'SS')   - payoff_M(regimes,'TS');
c_RoW_star(regimes) = payoff_RoW(regimes,'SS') - payoff_RoW(regimes,'ST');

* Central derived capture costs and GSF settings, from main_v3.gms.
PARAMETER capture_cost_M(regimes)
         / Baseline 8.36, Crisis 7.38, Boom 8.38, WarShock 11.05 /;
PARAMETER capture_cost_RoW(regimes)
         / Baseline 7.80, Crisis 8.42, Boom 7.25, WarShock 3.51 /;
PARAMETER gsf_resources(regimes)
         / Baseline 0, Crisis 11.0, Boom 11.0, WarShock 22.0 /;
SCALAR sigma_central / 0.6  /;
SCALAR mu_potency    / 0.84 /;
PARAMETER gsf_active(gsf) / off 0, on 1 /;

$INCLUDE mc_draws_capture.gms

* Crisis inherits the Boom pool shock, because the crisis-period fund
* draws down the stock accumulated in the preceding boom.
PARAMETER cM_s(sim, regimes), cR_s(sim, regimes), res_s(sim, regimes);
cM_s(sim, regimes) = capture_cost_M(regimes)   * mc_shock(sim, regimes, 'cM');
cR_s(sim, regimes) = capture_cost_RoW(regimes) * mc_shock(sim, regimes, 'cR');
res_s(sim, 'Baseline') = 0;
res_s(sim, 'Boom')     = gsf_resources('Boom')     * mc_pool_shock(sim, 'Boom');
res_s(sim, 'Crisis')   = gsf_resources('Crisis')   * mc_pool_shock(sim, 'Boom');
res_s(sim, 'WarShock') = gsf_resources('WarShock') * mc_pool_shock(sim, 'WarShock');

PARAMETER cM_eff_s(sim, regimes, gsf);
cM_eff_s(sim, regimes, gsf) = MAX(0, cM_s(sim, regimes)
    - gsf_active(gsf) * mu_potency * sigma_central * res_s(sim, regimes));

* Full Nash test of the (S,S) cell, with side diagnostics.
PARAMETER ok_M(sim, regimes, gsf), ok_R(sim, regimes), ss_is_NE(sim, regimes, gsf);
ok_M(sim, regimes, gsf)$(cM_eff_s(sim, regimes, gsf) <= c_M_star(regimes)) = 1;
ok_R(sim, regimes)$(cR_s(sim, regimes) <= c_RoW_star(regimes)) = 1;
ss_is_NE(sim, regimes, gsf) = ok_M(sim, regimes, gsf) * ok_R(sim, regimes);

PARAMETER p_SS(regimes, gsf), se_SS(regimes, gsf),
          ci_lo(regimes, gsf), ci_hi(regimes, gsf),
          n_fail(regimes, gsf), share_M_binds(regimes, gsf), share_R_binds(regimes, gsf);

p_SS(regimes, gsf)  = SUM(sim, ss_is_NE(sim, regimes, gsf)) / CARD(sim);
se_SS(regimes, gsf) = SQRT(p_SS(regimes,gsf) * (1 - p_SS(regimes,gsf)) / CARD(sim));
ci_lo(regimes, gsf) = MAX(0, p_SS(regimes,gsf) - 1.96 * se_SS(regimes,gsf));
ci_hi(regimes, gsf) = MIN(1, p_SS(regimes,gsf) + 1.96 * se_SS(regimes,gsf));

n_fail(regimes, gsf) = CARD(sim) - SUM(sim, ss_is_NE(sim, regimes, gsf));
share_M_binds(regimes, gsf)$(n_fail(regimes,gsf) > 0) =
    SUM(sim$(ok_M(sim,regimes,gsf) = 0), 1) / n_fail(regimes, gsf);
share_R_binds(regimes, gsf)$(n_fail(regimes,gsf) > 0) =
    SUM(sim$(ok_R(sim,regimes) = 0), 1) / n_fail(regimes, gsf);

DISPLAY p_SS, ci_lo, ci_hi, share_M_binds, share_R_binds;

FILE mcresults / results_montecarlo_v3.txt /;
PUT mcresults;
PUT "MONTE CARLO OVER CAPTURE COSTS AND GSF RESOURCES (N = 1,000, seed 42)" /;
PUT "=====================================================================" /;
PUT "Multiplicative uniform(0.75, 1.25) shocks on c_M, c_RoW and the pools" /;
PUT "sigma = ", sigma_central:4:2, ",  mu = ", mu_potency:4:2 /;
PUT " " /;
PUT "P[(S,S) is a Nash equilibrium], with 95 percent intervals" /;
PUT "Regime        GSF off  [   CI      ]     GSF on  [   CI      ]" /;
LOOP(regimes,
    PUT regimes.TL:12,
        p_SS(regimes,'off'):8:3, "  [", ci_lo(regimes,'off'):5:3, ",", ci_hi(regimes,'off'):5:3, "]",
        p_SS(regimes,'on'):9:3,  "  [", ci_lo(regimes,'on'):5:3,  ",", ci_hi(regimes,'on'):5:3,  "]" /;
);
PUT " " /;
PUT "AMONG FAILING DRAWS WITH THE GSF ON, WHICH SIDE BINDS" /;
PUT "(shares can exceed 100 pct because both sides can bind in one draw)" /;
LOOP(regimes$stoch_regimes(regimes),
    PUT regimes.TL:12, "  Malaysia ", (share_M_binds(regimes,'on')*100):6:1, " pct",
        "   RoW ", (share_R_binds(regimes,'on')*100):6:1, " pct" /;
);
PUT " " /;
PUT "Residual GSF-on risk at Omega = L is entirely RoW-side. Draws that push" /;
PUT "c_RoW above its flip threshold cannot be offset by Malaysian side" /;
PUT "payments at any saving rate, because the GSF reduces c_M only. At" /;
PUT "Omega = H both sides contribute to the residual risk." /;
PUT " " /;
PUT "The deterministic factorial in main_v3.gms reports the point" /;
PUT "calibration result. These frequencies quantify parametric uncertainty" /;
PUT "around it and should be reported alongside, not instead of, it." /;
CLOSE mcresults;

* ================= END OF MODEL =====================================
