$TITLE Malaysia Energy Geopolitics: sigma x es Equilibrium Map (v3)
* ====================================================================
* Supplementary Figure S3.
*
* WHAT CHANGED FROM v2. The earlier sensitivity file mapped the expected
* WELFARE advantage of the (S,S) cell over (T,T) across p_W and a GSF
* intensity index. Every cell of that grid was positive, which only
* restated the Pareto ranking already visible in Table 2, and the GSF
* term entered multiplied by p_W, so GSF intensity had no effect at
* p_W = 0. The grid therefore carried no equilibrium information.
*
* This file maps the EQUILIBRIUM REGION over the two parameters the
* result actually rests on:
*   sigma   the GSF saving rate, which Malaysia controls
*   es      the energy-security factor, which it does not
*
* Because the GSF reduces c_M only, a sufficiently high es blocks (S,S)
* at any saving rate. The frontier es_crit and its distance from the
* calibrated es value is the thinnest margin in the model.
*
* Region codes: 2 = (S,S) is a Nash equilibrium
*               1 = Malaysia willing, RoW side blocks
*               0 = Malaysia side blocks
* ====================================================================

SET regimes3 / Crisis, Boom, WarShock /;

PARAMETER payoff_M_TS(regimes3), payoff_M_SS(regimes3),
          payoff_R_ST(regimes3), payoff_R_SS(regimes3);
payoff_M_TS('Crisis') =  1.5;  payoff_M_SS('Crisis') =  8.5;
payoff_M_TS('Boom')   =  4.5;  payoff_M_SS('Boom')   =  9.0;
payoff_M_TS('WarShock') = 4.0; payoff_M_SS('WarShock') = 10.5;
payoff_R_ST('Crisis') =  2.5;  payoff_R_SS('Crisis') = 11.5;
payoff_R_ST('Boom')   =  3.0;  payoff_R_SS('Boom')   = 11.0;
payoff_R_ST('WarShock') = 1.5; payoff_R_SS('WarShock') = 12.5;

PARAMETER c_M_star(regimes3), c_RoW_star(regimes3);
c_M_star(regimes3)   = payoff_M_SS(regimes3) - payoff_M_TS(regimes3);
c_RoW_star(regimes3) = payoff_R_SS(regimes3) - payoff_R_ST(regimes3);

PARAMETER capture_cost_M(regimes3)
         / Crisis 7.376, Boom 8.382, WarShock 11.051 /;
PARAMETER gsf_resources(regimes3)
         / Crisis 11.0, Boom 11.0, WarShock 22.0 /;
PARAMETER es_calibrated(regimes3)
         / Crisis 1.08, Boom 0.93, WarShock 0.45 /;

SCALAR kappa_R / 120 /, fossil_sub_share / 0.065 /, mu_potency / 0.84 /;

PARAMETER es_critical(regimes3), es_headroom(regimes3);
es_critical(regimes3) = c_RoW_star(regimes3) / (kappa_R * fossil_sub_share);
es_headroom(regimes3) = (es_critical(regimes3) - es_calibrated(regimes3))
                        / es_calibrated(regimes3);

* Closed-form minimum saving rate, valid only where the RoW side allows it.
PARAMETER row_blocks(regimes3), sigma_min(regimes3);
row_blocks(regimes3)$(kappa_R * fossil_sub_share * es_calibrated(regimes3)
                      > c_RoW_star(regimes3)) = 1;
sigma_min(regimes3)$(row_blocks(regimes3) = 0) =
    MAX(0, (capture_cost_M(regimes3) - c_M_star(regimes3))
           / (mu_potency * gsf_resources(regimes3)));

* Grid.
SET sgrid / s0*s20 /;
SET egrid / e0*e26 /;
PARAMETER sigma_val(sgrid), es_val(egrid);
sigma_val(sgrid) = (ORD(sgrid)-1) * 0.05;
es_val(egrid)    = 0.30 + (ORD(egrid)-1) * 0.05;

PARAMETER cM_grid(sgrid, regimes3), cR_grid(egrid), region(egrid, sgrid, regimes3);
cM_grid(sgrid, regimes3) = MAX(0, capture_cost_M(regimes3)
    - mu_potency * sigma_val(sgrid) * gsf_resources(regimes3));
cR_grid(egrid) = kappa_R * fossil_sub_share * es_val(egrid);

region(egrid, sgrid, regimes3) = 0;
region(egrid, sgrid, regimes3)$(cM_grid(sgrid,regimes3) <= c_M_star(regimes3)) = 1;
region(egrid, sgrid, regimes3)$(
        cM_grid(sgrid,regimes3) <= c_M_star(regimes3)
    AND cR_grid(egrid)          <= c_RoW_star(regimes3)) = 2;

PARAMETER share_SS(regimes3);
share_SS(regimes3) = SUM((egrid, sgrid)$(region(egrid,sgrid,regimes3) = 2), 1)
                     / (CARD(egrid) * CARD(sgrid));

DISPLAY es_critical, es_headroom, sigma_min, share_SS, region;

FILE figS3 / results_figS3_v3.txt /;
PUT figS3;
PUT "SIGMA x ES EQUILIBRIUM MAP -- Supplementary Figure S3" /;
PUT "=====================================================" /;
PUT " " /;
PUT "Region codes: 2 = (S,S) is NE;  1 = RoW side blocks;  0 = M side blocks" /;
PUT " " /;
PUT "FRONTIERS AND HEADROOM" /;
PUT "Regime        es    es_crit   headroom%   sigma_min" /;
LOOP(regimes3,
    PUT regimes3.TL:10, es_calibrated(regimes3):7:2, es_critical(regimes3):10:4,
        (es_headroom(regimes3)*100):11:1;
    PUT$(row_blocks(regimes3) = 1) "        blocked" /;
    PUT$(row_blocks(regimes3) = 0) sigma_min(regimes3):12:3 /;
);
PUT " " /;
PUT "Share of the 27 x 21 grid in which (S,S) is a Nash equilibrium:" /;
LOOP(regimes3, PUT regimes3.TL:10, ": ", (share_SS(regimes3)*100):6:1, " pct" /; );
PUT " " /;
LOOP(regimes3,
    PUT " " /;
    PUT "REGION MAP -- ", regimes3.TL:10, "   rows = es, cols = sigma 0.00 to 1.00" /;
    LOOP(egrid,
        PUT "es=", es_val(egrid):5:2, " | ";
        LOOP(sgrid, PUT region(egrid, sgrid, regimes3):2:0);
        PUT /;
    );
);
PUT " " /;
PUT "Because the GSF reduces Malaysia's capture cost only, no saving rate" /;
PUT "recovers (S,S) once es exceeds es_crit. The Omega = L result rests on" /;
PUT "6.8 percent headroom in an assumed parameter, which should be" /;
PUT "disclosed rather than left implicit." /;
CLOSE figS3;

* ================= END OF MODEL =====================================
