# Data provenance and verification status

This file records where every input comes from and how well sourced it is.
It exists because the model mixes three very different kinds of input, and a
reader is entitled to know which is which.

| Tier | Meaning |
|---|---|
| **A** | Observed published statistic, traceable to a named document |
| **B** | Period average or ratio computed by the authors from tier A data |
| **C** | Set by argument or normalisation, not estimated from data |

A tier C input is not a defect. It is a defect only if it is presented as
though it were tier A. Everything below is labelled.

---

## The one input that needs further work

### `data/fiscal_inputs.csv`, column `subsidy_bill_myr_bn`

**Status: tier B, weakly sourced. Verification outstanding.**

Shipped values: Baseline 20, Crisis 14, Boom 28, WarShock 38 (MYR billion
per year).

This is the least well sourced input in the model, and it is a live input,
not a narrative figure. It enters the rent exposure ratio

    RER = (subsidy bill + petroleum revenue) / federal revenue

which sets `c_M` through `c_M = kappa_M * RER * A`. The baseline value of 20
therefore produces the `c_M = 8.36` reported in manuscript Table 3.

**Why it is hard to source.** Malaysian fuel subsidy figures vary by a factor
of three or more depending on scope, and the scope is rarely stated in
secondary sources:

1. Petroleum products only: RON95, diesel, LPG.
2. Plus electricity subsidy, including ICPT compensation paid to Tenaga
   Nasional, which only becomes a material line from roughly 2015.
3. The full Ministry of Finance operating expenditure line "Subsidies and
   Social Assistance", which also contains food and agriculture subsidies
   and cash transfers.
4. Wider government statements on "subsidies, incentives and social
   assistance", which are larger again.

The series is also not comparable across the whole window. Known or likely
breaks include the introduction of cash transfers from 2012, the managed
float of RON95 and diesel from December 2014, the appearance of ICPT
compensation from around 2015, a special Petronas dividend in 2019, and the
June 2024 diesel rationalisation.

**What to verify it against.** Ministry of Finance Malaysia, *Fiscal Outlook
and Federal Government Revenue Estimates*, annual. Each edition reports the
prior year outturn, so editions 2013 through 2026 cover outturns 2011
through 2024. The same document supplies the other three columns of
`fiscal_inputs.csv`, which is why the subsidy figure must not be replaced in
isolation: all four columns need to come from one accounting basis and one
set of years, or the ratio breaks.

**What the uncertainty does not change.** Run:

    python python/sensitivity_subsidy.py

Scaling the subsidy column across all four regimes from 0.7x to 3.0x, which
spans the full plausible scope range, leaves every equilibrium claim intact.
The baseline stays at (T,T). The boom and crisis regimes still flip to (S,S)
under the fund. The boom threshold `sigma_min` rises from 0.420 to at most
0.548, against a central saving rate of 0.6, so the margin narrows from
0.180 to 0.052 but never closes.

**What the uncertainty does change.** The reported levels. `c_M` for the
baseline moves from 8.36 to 11.78 across that range, and `c_M/c_M*` from
1.394 to 1.963. So if the calibration is revised, manuscript Table 3 and the
Table 3 note must both be regenerated. The equilibrium columns will not
move.

**Recommended handling.** Keep the current calibration, state the scope
explicitly in the source note, and report the sensitivity result in the
manuscript. That converts the weakest input from an exposure into a
documented robustness finding.

---

## Everything else

### `data/components.csv` — 32 gross payoffs

**Tier C, and disclosed as such.** Four component scores (E, I, SB, F) on a
0 to 20 scale, combined as `Pi = 0.25(E - I + SB + F)`. These scores
*decompose* the reported payoff matrix rather than deriving it from raw
indicators. `main_v3.gms` and `verify.py` both abort if any recomputed value
drifts from the reported matrix.

This is a regression guard and a transparency device. It is **not** an
external validation, and the manuscript says so in Supplementary Note S5.
Perturbing these scores cannot change any equilibrium condition, because
equilibria depend only on payoff differences and capture costs. That is why
the Monte Carlo targets capture costs instead.

### `data/regime_parameters.csv`

| Parameter | Tier | Note |
|---|---|---|
| `brent_low`, `brent_high` for B, L, H | A | Observed price bands, 1990 to 2024 |
| `brent_low`, `brent_high` for W | C | Stylised stress test. Not a forecast. Uses no observed post-2024 data |
| `regime_prob` | C | Section 3.8 baseline distribution. Baseline carries zero weight as the empirical anchor |
| `es_factor` | C | **Set by argument, not estimated.** See the fragility note below |
| `price_premium` | B | Computed from the price bands less the USD 80 trigger |
| `kappa_M`, `kappa_R` | C | Scaling constants. Cancel from the reported `c/c*` ratios |
| `lambda_d` | C | Fiscal stress amplifier slope |
| `fossil_sub_share` = 0.065 | A | Post-tax fossil subsidy share of world GDP, Coady et al. 2015 (IMF WP/15/105). **Note:** later IMF working papers revise this upward. If the manuscript cites the 2015 figure it should acknowledge the revision |
| `vol_mboed`, `window_months`, `fiscal_capture` | B | Volume, accumulation window and federal capture share |
| `sigma_central` = 0.6 | C | Policy instrument, not an observable |
| `gsf_trigger` = 80 | C | Design choice |

### `es_factor`: the thinnest margin in the model

**Tier C.** The crisis value of 1.08 rests on an argument, not an estimate.
The crisis result sits 6.8 percent below the RoW-side flip threshold. At
1.154 rather than 1.08 it would not obtain, and **no saving rate would
recover it**, because the fund reduces `c_M` alone.

This is the model's single most fragile claim and it is disclosed in
manuscript Section 4.7 and mapped in Supplementary Figure S3. Boom and
WarShock carry 10.3 and 213 percent headroom.

### `MU_POTENCY` (mu = 0.84), computed in `model.py`

**Tier C, by construction.** Set so that full deployment of the WarShock
pool at the central saving rate exactly neutralises the WarShock capture
cost:

    mu = c_M(W) / [sigma* * G(W)] = 11.05 / (0.6 * 22.0) = 0.84

The consequence deserves emphasis: **the Omega = W flip is guaranteed by the
anchoring and carries no independent evidential weight.** Its 213 percent
headroom is an artefact of the normalisation, not a finding. The boom flip
is the result that carries the argument, because it is not anchored. The
manuscript states the normalisation at Supplementary Note S4.

### GSF resources in the crisis regime

**Tier C, a modelling assumption.** The USD 80 trigger never fires at crisis
prices, so the crisis pool is zero. The crisis fund therefore disburses the
stock accumulated in the preceding boom. This counter-cyclical drawdown is
the mechanism the paper argues for, and the crisis flip depends entirely on
it. Stated in manuscript Section 3.6 and Supplementary Note S4.

### `data/mc_draws.csv`

**Tier B.** 4,000 rows: 1,000 draws for each of four regimes, seed 42, plus
or minus 25 percent shocks on `c_M`, `c_RoW` and the GSF pool. Regenerate
with `python python/make_draws.py`. The same draws are consumed by
`gams/mc_draws_capture.gms`, so the two implementations test identical
shocks.
