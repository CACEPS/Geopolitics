# Manuscript corrections log

Numbered log of text corrections identified by comparing the manuscript
against the model. `verify.py` refers to items here by number.

Status values: **OPEN** means the manuscript still needs the edit.
**RESOLVED** means the edit is present in the current version.

Checked against: **SFTR-D-26-02108 Manuscript R1 v6**.

---

## OPEN

### Item 1. Supplementary sigma_min for the crisis regime is stale
**Location:** Supplementary Note S4, note beneath the sigma sweep table.

The note reads "Minimum flip rates are sigma = 0.15 (crisis), 0.42 (boom),
and 0.25 (stress test)."

The model gives `sigma_min(Crisis) = 0.0407`. The main text was corrected and
now reads "any saving rate above 0.04". The supplementary note was not
updated, so the two contradict each other and the supplementary contradicts
the model.

**Fix:** change 0.15 to 0.04 in the supplementary note. The boom value 0.42
and stress test value 0.25 are correct.

### Item 2. Data availability statement contradicts the Appendix
**Location:** Data availability statement, and Appendix opening paragraph.

The statement says all data and code "are openly available" at the
repository URL. The Appendix says the files are "available in the
supplementary files or on request to the author(s)."

These cannot both stand, and "on request" now falls below most journals'
availability threshold.

**Fix:** delete the "or on request to the author(s)" clause and point the
Appendix at the same repository URL.

### Item 3. Both statements miscount the repository files
**Location:** Data availability statement, and Appendix.

Both say the repository contains three GAMS files. It contains four:
`main_v3.gms`, `montecarlo_v3.gms`, `sensitivity_v3.gms`, and
`mc_draws_capture.gms`.

The Appendix also says "one Python figure script". There are three figure
scripts, plus the model, the verifier, the Monte Carlo runner, the draw
generator, the subsidy sensitivity script and the number map generator.

**Fix:** say four GAMS files and an independent Python implementation, or
avoid counting and refer to the repository layout instead.

### Item 4. Subsidy figure scope is unstated
**Location:** Section 3.5 fiscal calibration, Supplementary Note S1.3, and
the fiscal inputs table.

The MYR 20 billion figure is given without stating which subsidy scope it
represents. Malaysian figures vary by a factor of three depending on whether
they cover petroleum products only, petroleum plus electricity and ICPT
compensation, or the full Ministry of Finance subsidies and social assistance
line.

**Fix:** state the scope, the source document and the period. Then add the
sensitivity result from `python/sensitivity_subsidy.py`: scaling the subsidy
column from 0.7x to 3.0x leaves every equilibrium claim intact, with the boom
threshold rising only from 0.420 to 0.548 against a central saving rate of
0.6. See `DATA_PROVENANCE.md`.

### Item 6. Coady et al. 2015 subsidy share may warrant a revision note
**Location:** Section 3.5.3, and `regime_parameters.csv` provenance field.

The 0.065 post-tax fossil subsidy share of world GDP is cited to Coady et
al. 2015. Later IMF working papers revise this figure upward. The anchor
itself remains defensible, but citing only the 2015 estimate without
acknowledging the revision invites a referee comment.

**Fix:** add one sentence noting the later revision, or state that the 2015
estimate is used for consistency with the calibration vintage.

---

## RESOLVED

### Item 5. es(Omega) fragility in the crisis regime was undisclosed
**Status: RESOLVED in R1 v6.**

The crisis result sits 6.8 percent below the RoW-side flip threshold, and no
saving rate can recover it because the fund reduces `c_M` alone. Section 4.7
now discloses this, gives the 1.154 flip point, and reports the 10.3 and 213
percent headroom for boom and stress test. Supplementary Figure S3 maps it.

`verify.py` previously printed "Disclose this" against this item. That
message was stale and has been corrected.

### Item 7. Table 2 double-star annotation was incomplete
**Status: RESOLVED in R1 v6.**

`S` is strictly dominant for both players with the fund on in both Omega = H
and Omega = W, so both qualify for the double-star label. An earlier version
starred Omega = W alone. Table 2 in R1 v6 double-stars both.

`verify.py` previously printed "Table 2 currently stars Omega = W alone".
That message was stale and has been corrected.

### Item 8. README mislabelled the regime-weighted probability
**Status: RESOLVED in the repository.**

The README stated that "regime-weighted P[(S,S) is a Nash equilibrium] is
0.000 without the fund and 1.000 with it". That phrasing borrows the label of
the Monte Carlo quantity, whose regime-weighted value with the fund on is

    0.45(0.639) + 0.35(0.626) + 0.20(1.000) = 0.707

not 1.000. The 0.000 and 1.000 figures are the deterministic factorial. As
written the README appeared to contradict Table S9.

The manuscript itself is correct: Section 4.7 reports the deterministic
factorial and Table S9 reports the per-regime Monte Carlo values. Only the
README needed the fix. Both aggregates are now stated explicitly and
distinguished in `NUMBER_MAP.md`.

### Item 9. NUMBER_MAP.md was labelled auto-generated but was not
**Status: RESOLVED in the repository.**

The file carried the header "Generated automatically; do not edit by hand"
and the README described it as auto-generated, but no script produced it. It
could drift from the model silently, and a referee following the regeneration
instruction got nothing.

`python/write_number_map.py` now generates it, and `verify.py` calls that
generator on every successful run.

### Item 10. Repository name was inconsistent across four places
**Status: RESOLVED in the repository.**

The published URL is `github.com/caceps/Geopolitics`. The distributed folder
was named `Geopolitics-GAMS`, the README clone command said
`Geopolitics.git`, and the README layout tree said `Geopolitics/`. The folder
is now `Geopolitics` throughout.
